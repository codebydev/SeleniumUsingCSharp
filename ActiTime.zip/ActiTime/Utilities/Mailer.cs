﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Net.Mime;
using System.Text;
using System.Threading.Tasks;

namespace ActiTime.Utilities
{
   public static class Mailer
    {
        const string SmtpServer = "smtp.live.com";
        const int SmtpPort = 587;
        const string FromAddress = ""; // Add email address here
        const string Password = ""; // Add mail password here

        public static void SendMail(string toAddress, string subject, string body)
        {
            var client = new SmtpClient(SmtpServer, SmtpPort)
            {
                Credentials = new NetworkCredential(FromAddress, Password),
                EnableSsl = true
            };

            MailMessage message = new MailMessage();
            Attachment attachment = new Attachment("report.html", MediaTypeNames.Application.Octet);
            message.Attachments.Add(attachment);

            foreach (var item in toAddress.Split(new[] { ";" }, StringSplitOptions.RemoveEmptyEntries))
            {
                message.To.Add(item);
            }

            message.From = new MailAddress(FromAddress);
            message.Body = body;
            message.Subject = subject;
            message.IsBodyHtml = true;
            try
            {
                client.Send(message);
            }
            catch (Exception e)
            {
                throw;
            }

        }
    }
}
