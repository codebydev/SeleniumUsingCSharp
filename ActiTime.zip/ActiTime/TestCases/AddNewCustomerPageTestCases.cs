﻿using ActiTime.PageActions;
using ActiTime.Pages.ProjectsAndTasks;
using ActiTime.Pages.ProjectsAndTasks.ProjectAndCustomers;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium.Support.PageObjects;
using RelevantCodes.ExtentReports;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ActiTime.TestCases
{
    [TestClass]
    public class AddNewCustomerPageTestCases: TestBase
    {
        // Add first new Customer
        [TestMethod]
        public void AddNewCustomerCreate()
        {
            LoginPageActions loginPageActions = new LoginPageActions(driver);
            loginPageActions.Login();
            navigation.ToProjectsAndCustomers();

            ProjectsAndCutomer projectsAndCutomer = new ProjectsAndCutomer();
            PageFactory.InitElements(driver, projectsAndCutomer);
            projectsAndCutomer.AddNewCustomer.Click();
            
            AddNewCustomerPage addNewCustomerPage = new AddNewCustomerPage();
            PageFactory.InitElements(driver, addNewCustomerPage);
            Random r = new Random();
            int temp = r.Next(1234,9999);

            addNewCustomerPage.CustomerName.SendKeys("Katti"+temp.ToString());
            //test.Log(LogStatus.Info, "Entered Customer Name");
            addNewCustomerPage.CustomerDescription.SendKeys("First Customer creating");
            //test.Log(LogStatus.Info, "Entered Customer Description");
            addNewCustomerPage.CreateUser.Click();
            //test.Log(LogStatus.Info, "Clicked on Create Customer button");
            //test.Log(LogStatus.Pass, "Executed all the test cases");

        }

        // Add new Customer without "Customer Description". Customer Description is not madetory field
        [TestMethod]
        public void AddNewCustomerCreateWithoutCutomerDescription()
        {
            LoginPageActions loginPageActions = new LoginPageActions(driver);
            loginPageActions.Login();
            navigation.ToProjectsAndCustomers();

            ProjectsAndCutomer projectsAndCutomer = new ProjectsAndCutomer();
            PageFactory.InitElements(driver, projectsAndCutomer);
            projectsAndCutomer.AddNewCustomer.Click();

            AddNewCustomerPage addNewCustomerPage = new AddNewCustomerPage();
            PageFactory.InitElements(driver, addNewCustomerPage);
            Random r = new Random();
            int temp = r.Next(1234, 9999);

            addNewCustomerPage.CustomerName.SendKeys("Katti"+temp.ToString());
            test.Log(LogStatus.Info, "Entered Customer Name");
            //addNewCustomerPage.CustomerDescription.SendKeys("First Customer creating");
            test.Log(LogStatus.Info, "Not Entered Customer Description");
            addNewCustomerPage.CreateUser.Click();
            test.Log(LogStatus.Info, "Clicked on Create Customer button");
            test.Log(LogStatus.Pass, "Executed all the test cases");

        }

        // Verify that, clicking on Cancel button, application wont create new customer and page navigates to previous page "Projects & Customers"
        [TestMethod]
        public void AddNewCustomerCancel()
        {
            LoginPageActions loginPageActions = new LoginPageActions(driver);
            loginPageActions.Login();
            navigation.ToProjectsAndCustomers();

            ProjectsAndCutomer projectsAndCutomer = new ProjectsAndCutomer();
            PageFactory.InitElements(driver, projectsAndCutomer);
            projectsAndCutomer.AddNewCustomer.Click();

            AddNewCustomerPage addNewCustomerPage = new AddNewCustomerPage();
            PageFactory.InitElements(driver, addNewCustomerPage);
            Random r = new Random();
            int temp = r.Next(1234, 9999);

            addNewCustomerPage.CustomerName.SendKeys("Katti"+temp.ToString());
            test.Log(LogStatus.Info, "Entered Customer Name");
            addNewCustomerPage.CustomerDescription.SendKeys("First Customer creating");
            test.Log(LogStatus.Info, "Entered Customer Description");

            addNewCustomerPage.Cancel.Click();
            test.Log(LogStatus.Info, "Clicked on Cancel button");
            driver.SwitchTo().Alert().Accept();
            test.Log(LogStatus.Pass, "Executed all the test cases");

        }

        //Create new Customer with option "Create a new project for this customer" by selecting the second Radio button
        [TestMethod]
        public void AddNewCustomerCreateUsingSecondRadioButton()
        {
            LoginPageActions loginPageActions = new LoginPageActions(driver);
            loginPageActions.Login();
            navigation.ToProjectsAndCustomers();

            ProjectsAndCutomer projectsAndCutomer = new ProjectsAndCutomer();
            PageFactory.InitElements(driver, projectsAndCutomer);
            projectsAndCutomer.AddNewCustomer.Click();

            AddNewCustomerPage addNewCustomerPage = new AddNewCustomerPage();
            PageFactory.InitElements(driver, addNewCustomerPage);
            Random r = new Random();
            int temp = r.Next(1234, 9999);

            addNewCustomerPage.CustomerName.SendKeys("Katti"+temp.ToString());
            test.Log(LogStatus.Info, "Entered Customer Name");
            addNewCustomerPage.CustomerDescription.SendKeys("First Customer creating");
            test.Log(LogStatus.Info, "Entered Customer Description");

            addNewCustomerPage.addProjectAction.Click();
            test.Log(LogStatus.Info, "Selected second radio button option");
            addNewCustomerPage.CreateUser.Click();
            test.Log(LogStatus.Info, "Clicked on Create Customer button");
            test.Log(LogStatus.Pass, "Executed all the test cases");

        }

        [TestMethod]
        public void AddNewCustomerCreateUsingThirdRadioButton()
        {
            LoginPageActions loginPageActions = new LoginPageActions(driver);
            loginPageActions.Login();
            navigation.ToProjectsAndCustomers();

            ProjectsAndCutomer projectsAndCutomer = new ProjectsAndCutomer();
            PageFactory.InitElements(driver, projectsAndCutomer);
            projectsAndCutomer.AddNewCustomer.Click();

            AddNewCustomerPage addNewCustomerPage = new AddNewCustomerPage();
            PageFactory.InitElements(driver, addNewCustomerPage);
            Random r = new Random();
            int temp = r.Next(1234, 9999);

            addNewCustomerPage.CustomerName.SendKeys("Katti"+temp.ToString());
            test.Log(LogStatus.Info, "Entered Customer Name");
            addNewCustomerPage.CustomerDescription.SendKeys("First Customer creating");
            test.Log(LogStatus.Info, "Entered Customer Description");
            addNewCustomerPage.addMoreCustomersAction.Click();
            test.Log(LogStatus.Info, "Selected second radio button option");
            addNewCustomerPage.CreateUser.Click();
            test.Log(LogStatus.Info, "Clicked on Create Customer button");
            test.Log(LogStatus.Pass, "Executed all the test cases");

        }

        [TestMethod]
        public void AddNewCustomerCreateWithoutCustomerName()
        {
            LoginPageActions loginPageActions = new LoginPageActions(driver);
            loginPageActions.Login();
            navigation.ToProjectsAndCustomers();

            ProjectsAndCutomer projectsAndCutomer = new ProjectsAndCutomer();
            PageFactory.InitElements(driver, projectsAndCutomer);
            projectsAndCutomer.AddNewCustomer.Click();

            AddNewCustomerPage addNewCustomerPage = new AddNewCustomerPage();
            PageFactory.InitElements(driver, addNewCustomerPage);


            //addNewCustomerPage.CustomerName.SendKeys("Katti_First_Customer");
            test.Log(LogStatus.Info, "Did not Entered Customer Name");
            addNewCustomerPage.CustomerDescription.SendKeys("First Customer creating");
            test.Log(LogStatus.Info, "Entered Customer Description");
            addNewCustomerPage.CreateUser.Click();
            test.Log(LogStatus.Info, "Clicked on Create Customer button");
            string actual= addNewCustomerPage.ErrorMessage.Text;
            Assert.AreEqual("All fields marked with * must be filled in. Please specify: Customer Name.", actual);
            test.Log(LogStatus.Pass, "Executed all the test cases");

        }

    }
}