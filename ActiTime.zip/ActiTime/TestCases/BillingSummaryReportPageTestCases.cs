﻿using ActiTime.PageActions;
using ActiTime.Pages.Reports;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ActiTime.TestCases
{
    [TestClass]

    public class BillingSummaryReportPageTestCases:TestBase
    {

        [TestMethod]
        public void BillingSummaryReportWithValidValues()
        {
            LoginPageActions loginPageActions = new LoginPageActions(driver);
            loginPageActions.Login();
            navigation.ToBillingSummaryReport();


            BillingSummaryReportPage billingSummaryReportPage = new BillingSummaryReportPage();
            PageFactory.InitElements(driver, billingSummaryReportPage);
            //billingSummaryReportPage.Timereportedforadaterange.Click();

            billingSummaryReportPage.Timespentontaskscompletedwithinadaterange.Click();

            billingSummaryReportPage.Month.Click();
            SelectElement SelectDropDownToMonth = new SelectElement(billingSummaryReportPage.Month);
            SelectDropDownToMonth.SelectByText("February");
            Thread.Sleep(2000);

            billingSummaryReportPage.Day.Click();
            billingSummaryReportPage.Year.Click();
            billingSummaryReportPage.SetCurrnetMonth.Click();
            Thread.Sleep(2000);

            billingSummaryReportPage.ToMonth.Click();
            billingSummaryReportPage.ToDay.Click();
            billingSummaryReportPage.ToYear.Click();
            billingSummaryReportPage.SetCurrnetWeek.Click();

            billingSummaryReportPage.Monthb.Click();
            billingSummaryReportPage.Weekb.Click();

            billingSummaryReportPage.NonBillabletasks.Click();
            billingSummaryReportPage.ReportOnActiveAndArchived.Click();

            billingSummaryReportPage.CustomerId.Click();

            SelectElement selectCustomerId = new SelectElement(billingSummaryReportPage.CustomerId);
            SelectDropDownToMonth.SelectByValue("1");
            Thread.Sleep(20000);


            billingSummaryReportPage.GenerateHTML.Click();

        }
    }
}