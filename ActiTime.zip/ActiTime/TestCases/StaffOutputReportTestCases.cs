﻿using ActiTime.PageActions;
using ActiTime.Pages;
using ActiTime.Pages.Reports;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using RelevantCodes.ExtentReports;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ActiTime.TestCases
{
    [TestClass]
    public class StaffOutputReportTestCases : TestBase
    {
        [TestMethod]
        public void VerifyUserClickOnAllBySelectingFirstGroupByDates()
        {
            LoginPageActions loginpageactions = new LoginPageActions(driver);
            loginpageactions.Login();

            navigation.ToStaffOutputReport();

            StaffOutputReportPagee staffpage = new StaffOutputReportPagee();
            PageFactory.InitElements(driver, staffpage);
            test.Log(LogStatus.Info, "Selected All Staff Successfully");
            staffpage.AllStaff.Click();

            //DropDown List 
            SelectElement dropdown = new SelectElement(staffpage.ResultByFirst);
            dropdown.SelectByValue("3");

            dropdown = new SelectElement(staffpage.groupBySecond);
            dropdown.SelectByValue("3");

            dropdown = new SelectElement(staffpage.Detail);
            dropdown.SelectByText("Hide tasks");

            dropdown = new SelectElement(staffpage.FromMonth);
            dropdown.SelectByText("August");

            dropdown = new SelectElement(staffpage.FromDay);
            dropdown.SelectByValue("10");

            dropdown = new SelectElement(staffpage.FromYear);
            dropdown.SelectByValue("2011");

            staffpage.SetCurrentMonth.Click();

            dropdown = new SelectElement(staffpage.ToMonth);
            dropdown.SelectByText("April");

            dropdown = new SelectElement(staffpage.ToDay);
            dropdown.SelectByValue("2");

            dropdown = new SelectElement(staffpage.ToYear);
            dropdown.SelectByValue("2010");

            staffpage.SetCurrentWeek.Click();

            staffpage.MonthGreaterThan.Click();

            staffpage.MonthLessThan.Click();

            staffpage.WeekLessThan.Click();

            staffpage.ReportOnActiveCustomersAndProjectsOnly.Click();

            dropdown = new SelectElement(staffpage.Customer);
            dropdown.SelectByValue("21");

            dropdown = new SelectElement(staffpage.Project);
            dropdown.SelectByValue("4");

            staffpage.GenerateHTMLReport.Click();
        }

        [TestMethod]
        public void VerifyingClickOnAllStaffBySelectingFirstGroupByCustomer()
        {
            LoginPageActions loginpageactions = new LoginPageActions(driver);
            loginpageactions.Login();

            navigation.ToStaffOutputReport();

            StaffOutputReportPagee staffpage = new StaffOutputReportPagee();
            PageFactory.InitElements(driver, staffpage);
            test.Log(LogStatus.Info, "Selected All Staff Successfully");
            staffpage.AllStaff.Click();

            //DropDown List 
            SelectElement dropdown = new SelectElement(staffpage.ResultByFirst);
            dropdown.SelectByValue("4");

            dropdown = new SelectElement(staffpage.groupBySecond);
            dropdown.SelectByValue("3");

            dropdown = new SelectElement(staffpage.Detail);
            dropdown.SelectByText("Hide tasks");

            dropdown = new SelectElement(staffpage.FromMonth);
            dropdown.SelectByText("March");

            dropdown = new SelectElement(staffpage.FromDay);
            dropdown.SelectByValue("5");

            dropdown = new SelectElement(staffpage.FromYear);
            dropdown.SelectByValue("2015");

            staffpage.SetCurrentMonth.Click();

            dropdown = new SelectElement(staffpage.ToMonth);
            dropdown.SelectByText("December");

            dropdown = new SelectElement(staffpage.ToDay);
            dropdown.SelectByValue("2");

            dropdown = new SelectElement(staffpage.ToYear);
            dropdown.SelectByValue("2014");

            staffpage.SetCurrentWeek.Click();

            staffpage.MonthGreaterThan.Click();

            staffpage.MonthLessThan.Click();

            staffpage.WeekLessThan.Click();

            staffpage.ReportOnActiveCustomersAndProjectsOnly.Click();

            dropdown = new SelectElement(staffpage.Customer);
            dropdown.SelectByValue("21");

            dropdown = new SelectElement(staffpage.Project);
            dropdown.SelectByValue("4");

            staffpage.GenerateCSVReport.Click();
        }

        [TestMethod]
        public void VerifyingClickOnAllStaffBySelectingFirstGroupByProject()
        {
            LoginPageActions loginpageactions = new LoginPageActions(driver);
            loginpageactions.Login();

            navigation.ToStaffOutputReport();

            StaffOutputReportPagee staffpage = new StaffOutputReportPagee();
            PageFactory.InitElements(driver, staffpage);
            test.Log(LogStatus.Info, "Selected All Staff Successfully");
            staffpage.AllStaff.Click();

            //DropDown List 
            SelectElement dropdown = new SelectElement(staffpage.ResultByFirst);
            dropdown.SelectByValue("5");

            dropdown = new SelectElement(staffpage.groupBySecond);
            dropdown.SelectByValue("3");

            dropdown = new SelectElement(staffpage.Detail);
            dropdown.SelectByText("Hide tasks");

            dropdown = new SelectElement(staffpage.FromMonth);
            dropdown.SelectByText("August");

            dropdown = new SelectElement(staffpage.FromDay);
            dropdown.SelectByValue("10");

            dropdown = new SelectElement(staffpage.FromYear);
            dropdown.SelectByValue("2015");

            staffpage.SetCurrentMonth.Click();

            dropdown = new SelectElement(staffpage.ToMonth);
            dropdown.SelectByText("April");

            dropdown = new SelectElement(staffpage.ToDay);
            dropdown.SelectByValue("2");

            dropdown = new SelectElement(staffpage.ToYear);
            dropdown.SelectByValue("2014");

            staffpage.SetCurrentWeek.Click();

            staffpage.MonthGreaterThan.Click();

            staffpage.MonthLessThan.Click();

            staffpage.WeekLessThan.Click();

            staffpage.ReportOnActiveCustomersAndProjectsOnly.Click();

            dropdown = new SelectElement(staffpage.Customer);
            dropdown.SelectByValue("21");

            dropdown = new SelectElement(staffpage.Project);
            dropdown.SelectByValue("4");

            staffpage.GenerateHTMLReport.Click();
        }

        [TestMethod]
        public void VerifyingClickOnAllStaffBySelectingFirstGroupByProjectNames()
        {
            LoginPageActions loginpageactions = new LoginPageActions(driver);
            loginpageactions.Login();

            navigation.ToStaffOutputReport();

            StaffOutputReportPagee staffpage = new StaffOutputReportPagee();
            PageFactory.InitElements(driver, staffpage);
            test.Log(LogStatus.Info, "Selected All Staff Successfully");
            staffpage.AllStaff.Click();

            //DropDown List 
            SelectElement dropdown = new SelectElement(staffpage.ResultByFirst);
            dropdown.SelectByValue("8");

            dropdown = new SelectElement(staffpage.groupBySecond);
            dropdown.SelectByValue("3");

            dropdown = new SelectElement(staffpage.Detail);
            dropdown.SelectByText("Hide tasks");

            dropdown = new SelectElement(staffpage.FromMonth);
            dropdown.SelectByText("August");

            dropdown = new SelectElement(staffpage.FromDay);
            dropdown.SelectByValue("10");

            dropdown = new SelectElement(staffpage.FromYear);
            dropdown.SelectByValue("2015");

            staffpage.SetCurrentMonth.Click();

            dropdown = new SelectElement(staffpage.ToMonth);
            dropdown.SelectByText("April");

            dropdown = new SelectElement(staffpage.ToDay);
            dropdown.SelectByValue("2");

            dropdown = new SelectElement(staffpage.ToYear);
            dropdown.SelectByValue("2012");

            staffpage.SetCurrentWeek.Click();

            staffpage.MonthGreaterThan.Click();

            staffpage.MonthLessThan.Click();

            staffpage.WeekLessThan.Click();

            staffpage.ReportOnActiveCustomersAndProjectsOnly.Click();

            dropdown = new SelectElement(staffpage.Customer);
            dropdown.SelectByValue("21");

            dropdown = new SelectElement(staffpage.Project);
            dropdown.SelectByValue("4");

            staffpage.GenerateHTMLReport.Click();
        }

        [TestMethod]
        public void VerifyingClickOnAllStaffBySelectingFirstGroupByTaskNames()
        {
            LoginPageActions loginpageactions = new LoginPageActions(driver);
            loginpageactions.Login();

            navigation.ToStaffOutputReport();

            StaffOutputReportPagee staffpage = new StaffOutputReportPagee();
            PageFactory.InitElements(driver, staffpage);
            test.Log(LogStatus.Info, "Selected All Staff Successfully");
            staffpage.AllStaff.Click();

            //DropDown List 
            SelectElement dropdown = new SelectElement(staffpage.ResultByFirst);
            dropdown.SelectByValue("2");

            dropdown = new SelectElement(staffpage.groupBySecond);
            dropdown.SelectByValue("3");

            dropdown = new SelectElement(staffpage.Detail);
            dropdown.SelectByText("Hide tasks");

            dropdown = new SelectElement(staffpage.FromMonth);
            dropdown.SelectByText("August");

            dropdown = new SelectElement(staffpage.FromDay);
            dropdown.SelectByValue("10");

            dropdown = new SelectElement(staffpage.FromYear);
            dropdown.SelectByValue("2015");

            staffpage.SetCurrentMonth.Click();

            dropdown = new SelectElement(staffpage.ToMonth);
            dropdown.SelectByText("April");

            dropdown = new SelectElement(staffpage.ToDay);
            dropdown.SelectByValue("2");

            dropdown = new SelectElement(staffpage.ToYear);
            dropdown.SelectByValue("2014");

            staffpage.SetCurrentWeek.Click();

            staffpage.MonthGreaterThan.Click();

            staffpage.MonthLessThan.Click();

            staffpage.WeekLessThan.Click();

            staffpage.ReportOnActiveCustomersAndProjectsOnly.Click();

            dropdown = new SelectElement(staffpage.Customer);
            dropdown.SelectByValue("21");

            dropdown = new SelectElement(staffpage.Project);
            dropdown.SelectByValue("4");

            staffpage.GenerateHTMLReport.Click();
        }

        [TestMethod]
        public void VerifyingClickOnAllStaffBySelectingFirstGroupByBillingTypes()
        {
            LoginPageActions loginpageactions = new LoginPageActions(driver);
            loginpageactions.Login();

            navigation.ToStaffOutputReport();

            StaffOutputReportPagee staffpage = new StaffOutputReportPagee();
            PageFactory.InitElements(driver, staffpage);
            test.Log(LogStatus.Info, "Selected All Staff Successfully");
            staffpage.AllStaff.Click();

            //DropDown List 
            SelectElement dropdown = new SelectElement(staffpage.ResultByFirst);
            dropdown.SelectByValue("2");

            dropdown = new SelectElement(staffpage.groupBySecond);
            dropdown.SelectByValue("3");

            dropdown = new SelectElement(staffpage.Detail);
            dropdown.SelectByText("Hide tasks");

            dropdown = new SelectElement(staffpage.FromMonth);
            dropdown.SelectByText("August");

            dropdown = new SelectElement(staffpage.FromDay);
            dropdown.SelectByValue("10");

            dropdown = new SelectElement(staffpage.FromYear);
            dropdown.SelectByValue("2015");

            staffpage.SetCurrentMonth.Click();

            dropdown = new SelectElement(staffpage.ToMonth);
            dropdown.SelectByText("April");

            dropdown = new SelectElement(staffpage.ToDay);
            dropdown.SelectByValue("2");

            dropdown = new SelectElement(staffpage.ToYear);
            dropdown.SelectByValue("2014");

            staffpage.SetCurrentWeek.Click();

            staffpage.MonthGreaterThan.Click();

            staffpage.MonthLessThan.Click();

            staffpage.WeekLessThan.Click();

            staffpage.ReportOnActiveCustomersAndProjectsOnly.Click();

            dropdown = new SelectElement(staffpage.Customer);
            dropdown.SelectByValue("21");

            dropdown = new SelectElement(staffpage.Project);
            dropdown.SelectByValue("4");

            staffpage.GenerateHTMLReport.Click();
        }


        [TestMethod]
        public void VerifyingClickOnAllStaffBySelectingThenGroupByNothing()
        {
            LoginPageActions loginpageactions = new LoginPageActions(driver);
            loginpageactions.Login();

            navigation.ToStaffOutputReport();

            StaffOutputReportPagee staffpage = new StaffOutputReportPagee();
            PageFactory.InitElements(driver, staffpage);
            test.Log(LogStatus.Info, "Selected All Staff Successfully");
            staffpage.AllStaff.Click();

            //DropDown List 
            SelectElement dropdown = new SelectElement(staffpage.ResultByFirst);
            dropdown.SelectByValue("2");

            dropdown = new SelectElement(staffpage.groupBySecond);
            dropdown.SelectByValue("7");

            dropdown = new SelectElement(staffpage.Detail);
            dropdown.SelectByText("Hide tasks");

            dropdown = new SelectElement(staffpage.FromMonth);
            dropdown.SelectByText("August");

            dropdown = new SelectElement(staffpage.FromDay);
            dropdown.SelectByValue("10");

            dropdown = new SelectElement(staffpage.FromYear);
            dropdown.SelectByValue("2015");

            staffpage.SetCurrentMonth.Click();

            dropdown = new SelectElement(staffpage.ToMonth);
            dropdown.SelectByText("April");

            dropdown = new SelectElement(staffpage.ToDay);
            dropdown.SelectByValue("2");

            dropdown = new SelectElement(staffpage.ToYear);
            dropdown.SelectByValue("2014");

            staffpage.SetCurrentWeek.Click();

            staffpage.MonthGreaterThan.Click();

            staffpage.MonthLessThan.Click();

            staffpage.WeekLessThan.Click();

            staffpage.ReportOnActiveCustomersAndProjectsOnly.Click();

            dropdown = new SelectElement(staffpage.Customer);
            dropdown.SelectByValue("21");

            dropdown = new SelectElement(staffpage.Project);
            dropdown.SelectByValue("4");

            staffpage.GenerateHTMLReport.Click();
        }

        [TestMethod]
        public void VerifyingClickOnAllStaffBySelectingThenGroupByCustomer()
        {
            LoginPageActions loginpageactions = new LoginPageActions(driver);
            loginpageactions.Login();

            navigation.ToStaffOutputReport();

            StaffOutputReportPagee staffpage = new StaffOutputReportPagee();
            PageFactory.InitElements(driver, staffpage);
            test.Log(LogStatus.Info, "Selected All Staff Successfully");
            staffpage.AllStaff.Click();

            //DropDown List 
            SelectElement dropdown = new SelectElement(staffpage.ResultByFirst);
            dropdown.SelectByValue("2");

            dropdown = new SelectElement(staffpage.groupBySecond);
            dropdown.SelectByValue("7");

            dropdown = new SelectElement(staffpage.Detail);
            dropdown.SelectByText("Hide tasks");

            dropdown = new SelectElement(staffpage.FromMonth);
            dropdown.SelectByText("August");

            dropdown = new SelectElement(staffpage.FromDay);
            dropdown.SelectByValue("10");

            dropdown = new SelectElement(staffpage.FromYear);
            dropdown.SelectByValue("2015");

            staffpage.SetCurrentMonth.Click();

            dropdown = new SelectElement(staffpage.ToMonth);
            dropdown.SelectByText("November");

            dropdown = new SelectElement(staffpage.ToDay);
            dropdown.SelectByValue("2");

            dropdown = new SelectElement(staffpage.ToYear);
            dropdown.SelectByValue("2014");

            staffpage.SetCurrentWeek.Click();

            staffpage.MonthGreaterThan.Click();

            staffpage.MonthLessThan.Click();

            staffpage.WeekLessThan.Click();

            staffpage.ReportOnActiveCustomersAndProjectsOnly.Click();

            dropdown = new SelectElement(staffpage.Customer);
            dropdown.SelectByValue("21");

            dropdown = new SelectElement(staffpage.Project);
            dropdown.SelectByValue("4");

            staffpage.GenerateHTMLReport.Click();
        }

        [TestMethod]
        public void VerifyingClickOnAllStaffBySelectingThenGroupByProjects()
        {
            LoginPageActions loginpageactions = new LoginPageActions(driver);
            loginpageactions.Login();

            navigation.ToStaffOutputReport();

            StaffOutputReportPagee staffpage = new StaffOutputReportPagee();
            PageFactory.InitElements(driver, staffpage);
            test.Log(LogStatus.Info, "Selected All Staff Successfully");
            staffpage.AllStaff.Click();

            //DropDown List 
            SelectElement dropdown = new SelectElement(staffpage.ResultByFirst);
            dropdown.SelectByValue("2");

            dropdown = new SelectElement(staffpage.groupBySecond);
            dropdown.SelectByValue("5");

            dropdown = new SelectElement(staffpage.Detail);
            dropdown.SelectByText("Hide tasks");

            dropdown = new SelectElement(staffpage.FromMonth);
            dropdown.SelectByText("August");

            dropdown = new SelectElement(staffpage.FromDay);
            dropdown.SelectByValue("10");

            dropdown = new SelectElement(staffpage.FromYear);
            dropdown.SelectByValue("2015");

            staffpage.SetCurrentMonth.Click();

            dropdown = new SelectElement(staffpage.ToMonth);
            dropdown.SelectByText("April");

            dropdown = new SelectElement(staffpage.ToDay);
            dropdown.SelectByValue("2");

            dropdown = new SelectElement(staffpage.ToYear);
            dropdown.SelectByValue("2014");

            staffpage.SetCurrentWeek.Click();

            staffpage.MonthGreaterThan.Click();

            staffpage.MonthLessThan.Click();

            staffpage.WeekLessThan.Click();

            staffpage.ReportOnActiveCustomersAndProjectsOnly.Click();

            dropdown = new SelectElement(staffpage.Customer);
            dropdown.SelectByValue("21");

            dropdown = new SelectElement(staffpage.Project);
            dropdown.SelectByValue("4");

            staffpage.GenerateHTMLReport.Click();
        }

        [TestMethod]
        public void VerifyingClickOnAllStaffBySelectingThenGroupByProjectNames()
        {
            LoginPageActions loginpageactions = new LoginPageActions(driver);
            loginpageactions.Login();

            navigation.ToStaffOutputReport();

            StaffOutputReportPagee staffpage = new StaffOutputReportPagee();
            PageFactory.InitElements(driver, staffpage);
            test.Log(LogStatus.Info, "Selected All Staff Successfully");
            staffpage.AllStaff.Click();

            //DropDown List 
            SelectElement dropdown = new SelectElement(staffpage.ResultByFirst);
            dropdown.SelectByValue("2");

            dropdown = new SelectElement(staffpage.groupBySecond);
            dropdown.SelectByValue("8");

            dropdown = new SelectElement(staffpage.Detail);
            dropdown.SelectByText("Hide tasks");

            dropdown = new SelectElement(staffpage.FromMonth);
            dropdown.SelectByText("November");

            dropdown = new SelectElement(staffpage.FromDay);
            dropdown.SelectByValue("10");

            dropdown = new SelectElement(staffpage.FromYear);
            dropdown.SelectByValue("2015");

            staffpage.SetCurrentMonth.Click();

            dropdown = new SelectElement(staffpage.ToMonth);
            dropdown.SelectByText("April");

            dropdown = new SelectElement(staffpage.ToDay);
            dropdown.SelectByValue("2");

            dropdown = new SelectElement(staffpage.ToYear);
            dropdown.SelectByValue("2014");

            staffpage.SetCurrentWeek.Click();

            staffpage.MonthGreaterThan.Click();

            staffpage.MonthLessThan.Click();

            staffpage.WeekLessThan.Click();

            staffpage.ReportOnActiveCustomersAndProjectsOnly.Click();

            dropdown = new SelectElement(staffpage.Customer);
            dropdown.SelectByValue("21");

            dropdown = new SelectElement(staffpage.Project);
            dropdown.SelectByValue("4");

            staffpage.GenerateHTMLReport.Click();
        }

        //[TestMethod]
        //public void VerifyingClickOnAllStaffBySelectingThenGroupByTaskNames()
        //{
        //    LoginPageActions loginpageactions = new LoginPageActions(driver);
        //    loginpageactions.Login();

        //    navigation.ToStaffOutputReport();

        //    StaffOutputReportPagee staffpage = new StaffOutputReportPagee();
        //    PageFactory.InitElements(driver, staffpage);
        //    test.Log(LogStatus.Info, "Selected All Staff Successfully");
        //    staffpage.AllStaff.Click();

        //    //DropDown List 
        //    SelectElement dropdown = new SelectElement(staffpage.ResultByFirst);
        //    dropdown.SelectByValue("2");

        //    dropdown = new SelectElement(staffpage.groupBySecond);
        //    dropdown.SelectByValue("9");

        //    dropdown = new SelectElement(staffpage.Detail);
        //    dropdown.SelectByText("Hide tasks");

        //    dropdown = new SelectElement(staffpage.FromMonth);
        //    dropdown.SelectByText("August");

        //    dropdown = new SelectElement(staffpage.FromDay);
        //    dropdown.SelectByValue("10");

        //    dropdown = new SelectElement(staffpage.FromYear);
        //    dropdown.SelectByValue("2015");

        //    staffpage.SetCurrentMonth.Click();

        //    dropdown = new SelectElement(staffpage.ToMonth);
        //    dropdown.SelectByText("April");

        //    dropdown = new SelectElement(staffpage.ToDay);
        //    dropdown.SelectByValue("2");

        //    dropdown = new SelectElement(staffpage.ToYear);
        //    dropdown.SelectByValue("2014");

        //    staffpage.SetCurrentWeek.Click();

        //    staffpage.MonthGreaterThan.Click();

        //    staffpage.MonthLessThan.Click();

        //    staffpage.WeekLessThan.Click();

        //    staffpage.ReportOnActiveCustomersAndProjectsOnly.Click();

        //    dropdown = new SelectElement(staffpage.Customer);
        //    dropdown.SelectByValue("21");

        //    dropdown = new SelectElement(staffpage.Project);
        //    dropdown.SelectByValue("4");

        //    staffpage.GenerateHTMLReport.Click();
        //}

        [TestMethod]
        public void VerifyingClickOnAllStaffBySelectingThenGroupByBillingTypes()
        {
            LoginPageActions loginpageactions = new LoginPageActions(driver);
            loginpageactions.Login();

            navigation.ToStaffOutputReport();

            StaffOutputReportPagee staffpage = new StaffOutputReportPagee();
            PageFactory.InitElements(driver, staffpage);
            test.Log(LogStatus.Info, "Selected All Staff Successfully");
            staffpage.AllStaff.Click();

            //DropDown List 
            SelectElement dropdown = new SelectElement(staffpage.ResultByFirst);
            dropdown.SelectByValue("2");

            dropdown = new SelectElement(staffpage.groupBySecond);
            dropdown.SelectByValue("2");

            dropdown = new SelectElement(staffpage.Detail);
            dropdown.SelectByText("Hide tasks");

            dropdown = new SelectElement(staffpage.FromMonth);
            dropdown.SelectByText("August");

            dropdown = new SelectElement(staffpage.FromDay);
            dropdown.SelectByValue("10");

            dropdown = new SelectElement(staffpage.FromYear);
            dropdown.SelectByValue("2015");

            staffpage.SetCurrentMonth.Click();

            dropdown = new SelectElement(staffpage.ToMonth);
            dropdown.SelectByText("April");

            dropdown = new SelectElement(staffpage.ToDay);
            dropdown.SelectByValue("2");

            dropdown = new SelectElement(staffpage.ToYear);
            dropdown.SelectByValue("2014");

            staffpage.SetCurrentWeek.Click();

            staffpage.MonthGreaterThan.Click();

            staffpage.MonthLessThan.Click();

            staffpage.WeekLessThan.Click();

            staffpage.ReportOnActiveCustomersAndProjectsOnly.Click();

            dropdown = new SelectElement(staffpage.Customer);
            dropdown.SelectByValue("21");

            dropdown = new SelectElement(staffpage.Project);
            dropdown.SelectByValue("4");

            staffpage.GenerateHTMLReport.Click();
        }




        [TestMethod]
        public void VerifyingClickOnAllStaffBySelectingHideTaskDetails()
        {
            LoginPageActions loginpageactions = new LoginPageActions(driver);
            loginpageactions.Login();

            navigation.ToStaffOutputReport();

            StaffOutputReportPagee staffpage = new StaffOutputReportPagee();
            PageFactory.InitElements(driver, staffpage);
            test.Log(LogStatus.Info, "Selected All Staff Successfully");
            staffpage.AllStaff.Click();

            //DropDown List 
            SelectElement dropdown = new SelectElement(staffpage.ResultByFirst);
            dropdown.SelectByValue("2");

            dropdown = new SelectElement(staffpage.groupBySecond);
            dropdown.SelectByValue("7");

            dropdown = new SelectElement(staffpage.Detail);
            dropdown.SelectByText("Hide tasks");

            dropdown = new SelectElement(staffpage.FromMonth);
            dropdown.SelectByText("August");

            dropdown = new SelectElement(staffpage.FromDay);
            dropdown.SelectByValue("10");

            dropdown = new SelectElement(staffpage.FromYear);
            dropdown.SelectByValue("2015");

            staffpage.SetCurrentMonth.Click();

            dropdown = new SelectElement(staffpage.ToMonth);
            dropdown.SelectByText("April");

            dropdown = new SelectElement(staffpage.ToDay);
            dropdown.SelectByValue("2");

            dropdown = new SelectElement(staffpage.ToYear);
            dropdown.SelectByValue("2014");

            staffpage.SetCurrentWeek.Click();

            staffpage.MonthGreaterThan.Click();

            staffpage.MonthLessThan.Click();

            staffpage.WeekLessThan.Click();

            staffpage.ReportOnActiveAndArchivedCustomersOrprojects.Click();

            dropdown = new SelectElement(staffpage.Customer);
            dropdown.SelectByValue("21");

            dropdown = new SelectElement(staffpage.Project);
            dropdown.SelectByValue("4");

            staffpage.GenerateHTMLReport.Click();
        }

        [TestMethod]
        public void VerifyingClickOnAllStaffBySelectingShowTaskDetails()
        {
            LoginPageActions loginpageactions = new LoginPageActions(driver);
            loginpageactions.Login();

            navigation.ToStaffOutputReport();

            StaffOutputReportPagee staffpage = new StaffOutputReportPagee();
            PageFactory.InitElements(driver, staffpage);
            test.Log(LogStatus.Info, "Selected All Staff Successfully");
            staffpage.AllStaff.Click();

            //DropDown List 
            SelectElement dropdown = new SelectElement(staffpage.ResultByFirst);
            dropdown.SelectByValue("2");

            dropdown = new SelectElement(staffpage.groupBySecond);
            dropdown.SelectByValue("7");

            dropdown = new SelectElement(staffpage.Detail);
            dropdown.SelectByText("Show tasks");

            dropdown = new SelectElement(staffpage.FromMonth);
            dropdown.SelectByText("August");

            dropdown = new SelectElement(staffpage.FromDay);
            dropdown.SelectByValue("10");

            dropdown = new SelectElement(staffpage.FromYear);
            dropdown.SelectByValue("2015");

            staffpage.SetCurrentMonth.Click();

            dropdown = new SelectElement(staffpage.ToMonth);
            dropdown.SelectByText("April");

            dropdown = new SelectElement(staffpage.ToDay);
            dropdown.SelectByValue("2");

            dropdown = new SelectElement(staffpage.ToYear);
            dropdown.SelectByValue("2014");

            staffpage.SetCurrentWeek.Click();

            staffpage.MonthGreaterThan.Click();

            staffpage.MonthLessThan.Click();

            staffpage.WeekLessThan.Click();

            staffpage.ReportOnActiveCustomersAndProjectsOnly.Click();

            dropdown = new SelectElement(staffpage.Customer);
            dropdown.SelectByValue("21");

            dropdown = new SelectElement(staffpage.Project);
            dropdown.SelectByValue("4");

            staffpage.GenerateHTMLReport.Click();
        }
        //ON SELECTED STAFF
        //[TestMethod]
        //public void VerifyUserClickOnSelectedStaff()
        //{

        //    LoginPageActions loginpageactions = new LoginPageActions(driver);
        //    loginpageactions.Login();

        //    navigation.ToStaffOutputReport();

        //    StaffOutputReportPagee staffpage = new StaffOutputReportPagee();
        //    PageFactory.InitElements(driver, staffpage);
        //    test.Log(LogStatus.Info, "Selected All Staff Successfully");
        //    staffpage.SelectedStaff.Click();

        //    //DropDown List 
        //    SelectElement dropdown = new SelectElement(staffpage.ResultByFirst);
        //    dropdown.SelectByValue("3");

        //    dropdown = new SelectElement(staffpage.groupBySecond);
        //    dropdown.SelectByValue("3");

        //    dropdown = new SelectElement(staffpage.Detail);
        //    dropdown.SelectByText("Hide tasks");

        //    dropdown = new SelectElement(staffpage.FromMonth);
        //    dropdown.SelectByText("August");

        //    dropdown = new SelectElement(staffpage.FromDay);
        //    dropdown.SelectByValue("10");

        //    dropdown = new SelectElement(staffpage.FromYear);
        //    dropdown.SelectByValue("2015");

        //    staffpage.SetCurrentMonth.Click();

        //    dropdown = new SelectElement(staffpage.ToMonth);
        //    dropdown.SelectByText("April");

        //    dropdown = new SelectElement(staffpage.ToDay);
        //    dropdown.SelectByValue("2");

        //    dropdown = new SelectElement(staffpage.ToYear);
        //    dropdown.SelectByValue("2014");

        //    staffpage.SetCurrentWeek.Click();

        //    staffpage.MonthGreaterThan.Click();

        //    staffpage.MonthLessThan.Click();

        //    staffpage.WeekLessThan.Click();

        //    staffpage.ReportOnActiveCustomersAndProjectsOnly.Click();

        //    dropdown = new SelectElement(staffpage.Customer);
        //    dropdown.SelectByValue("21");

        //    dropdown = new SelectElement(staffpage.Project);
        //    dropdown.SelectByValue("4");

        //    staffpage.GenerateCSVReport.Click();
        //}

        [TestMethod]
        public void VerifyingClickOnSelectedStaffBySelectingFirstGroupByCustomer()
        {
            LoginPageActions loginpageactions = new LoginPageActions(driver);
            loginpageactions.Login();

            navigation.ToStaffOutputReport();

            StaffOutputReportPagee staffpage = new StaffOutputReportPagee();
            PageFactory.InitElements(driver, staffpage);
            test.Log(LogStatus.Info, "Selected All Staff Successfully");
            staffpage.AllStaff.Click();

            //DropDown List 
            SelectElement dropdown = new SelectElement(staffpage.ResultByFirst);
            dropdown.SelectByValue("4");

            dropdown = new SelectElement(staffpage.groupBySecond);
            dropdown.SelectByValue("3");

            dropdown = new SelectElement(staffpage.Detail);
            dropdown.SelectByText("Hide tasks");

            dropdown = new SelectElement(staffpage.FromMonth);
            dropdown.SelectByText("August");

            dropdown = new SelectElement(staffpage.FromDay);
            dropdown.SelectByValue("10");

            dropdown = new SelectElement(staffpage.FromYear);
            dropdown.SelectByValue("2015");

            staffpage.SetCurrentMonth.Click();

            dropdown = new SelectElement(staffpage.ToMonth);
            dropdown.SelectByText("April");

            dropdown = new SelectElement(staffpage.ToDay);
            dropdown.SelectByValue("2");

            dropdown = new SelectElement(staffpage.ToYear);
            dropdown.SelectByValue("2014");

            staffpage.SetCurrentWeek.Click();

            staffpage.MonthGreaterThan.Click();

            staffpage.MonthLessThan.Click();

            staffpage.WeekLessThan.Click();

            staffpage.ReportOnActiveCustomersAndProjectsOnly.Click();

            dropdown = new SelectElement(staffpage.Customer);
            dropdown.SelectByValue("21");

            dropdown = new SelectElement(staffpage.Project);
            dropdown.SelectByValue("4");

            staffpage.GenerateHTMLReport.Click();
        }
        [TestMethod]

        public void VerifyingClickOnSelectedStaffBySelectingFirstGroupByProject()
        {
            LoginPageActions loginpageactions = new LoginPageActions(driver);
            loginpageactions.Login();

            navigation.ToStaffOutputReport();

            StaffOutputReportPagee staffpage = new StaffOutputReportPagee();
            PageFactory.InitElements(driver, staffpage);
            test.Log(LogStatus.Info, "Selected All Staff Successfully");
            staffpage.AllStaff.Click();

            //DropDown List 
            SelectElement dropdown = new SelectElement(staffpage.ResultByFirst);
            dropdown.SelectByValue("5");

            dropdown = new SelectElement(staffpage.groupBySecond);
            dropdown.SelectByValue("3");

            dropdown = new SelectElement(staffpage.Detail);
            dropdown.SelectByText("Hide tasks");

            dropdown = new SelectElement(staffpage.FromMonth);
            dropdown.SelectByText("August");

            dropdown = new SelectElement(staffpage.FromDay);
            dropdown.SelectByValue("10");

            dropdown = new SelectElement(staffpage.FromYear);
            dropdown.SelectByValue("2015");

            staffpage.SetCurrentMonth.Click();

            dropdown = new SelectElement(staffpage.ToMonth);
            dropdown.SelectByText("April");

            dropdown = new SelectElement(staffpage.ToDay);
            dropdown.SelectByValue("2");

            dropdown = new SelectElement(staffpage.ToYear);
            dropdown.SelectByValue("2014");

            staffpage.SetCurrentWeek.Click();

            staffpage.MonthGreaterThan.Click();

            staffpage.MonthLessThan.Click();

            staffpage.WeekLessThan.Click();

            staffpage.ReportOnActiveCustomersAndProjectsOnly.Click();

            dropdown = new SelectElement(staffpage.Customer);
            dropdown.SelectByValue("21");

            dropdown = new SelectElement(staffpage.Project);
            dropdown.SelectByValue("4");

            staffpage.GenerateHTMLReport.Click();
        }
        [TestMethod]
        public void VerifyingClickOnSelectedStaffBySelectingFirstGroupByProjectNames()
        {
            LoginPageActions loginpageactions = new LoginPageActions(driver);
            loginpageactions.Login();

            navigation.ToStaffOutputReport();

            StaffOutputReportPagee staffpage = new StaffOutputReportPagee();
            PageFactory.InitElements(driver, staffpage);
            test.Log(LogStatus.Info, "Selected All Staff Successfully");
            staffpage.AllStaff.Click();

            //DropDown List 
            SelectElement dropdown = new SelectElement(staffpage.ResultByFirst);
            dropdown.SelectByValue("8");

            dropdown = new SelectElement(staffpage.groupBySecond);
            dropdown.SelectByValue("3");

            dropdown = new SelectElement(staffpage.Detail);
            dropdown.SelectByText("Hide tasks");

            dropdown = new SelectElement(staffpage.FromMonth);
            dropdown.SelectByText("August");

            dropdown = new SelectElement(staffpage.FromDay);
            dropdown.SelectByValue("10");

            dropdown = new SelectElement(staffpage.FromYear);
            dropdown.SelectByValue("2015");

            staffpage.SetCurrentMonth.Click();

            dropdown = new SelectElement(staffpage.ToMonth);
            dropdown.SelectByText("April");

            dropdown = new SelectElement(staffpage.ToDay);
            dropdown.SelectByValue("2");

            dropdown = new SelectElement(staffpage.ToYear);
            dropdown.SelectByValue("2014");

            staffpage.SetCurrentWeek.Click();

            staffpage.MonthGreaterThan.Click();

            staffpage.MonthLessThan.Click();

            staffpage.WeekLessThan.Click();

            staffpage.ReportOnActiveCustomersAndProjectsOnly.Click();

            dropdown = new SelectElement(staffpage.Customer);
            dropdown.SelectByValue("21");

            dropdown = new SelectElement(staffpage.Project);
            dropdown.SelectByValue("4");

            staffpage.GenerateHTMLReport.Click();
        }

        [TestMethod]
        public void VerifyingClickOnSelectedStaffBySelectingFirstGroupByBillingTypes()
        {
            LoginPageActions loginpageactions = new LoginPageActions(driver);
            loginpageactions.Login();

            navigation.ToStaffOutputReport();

            StaffOutputReportPagee staffpage = new StaffOutputReportPagee();
            PageFactory.InitElements(driver, staffpage);
            test.Log(LogStatus.Info, "Selected All Staff Successfully");
            staffpage.AllStaff.Click();

            //DropDown List 
            SelectElement dropdown = new SelectElement(staffpage.ResultByFirst);
            dropdown.SelectByValue("2");

            dropdown = new SelectElement(staffpage.groupBySecond);
            dropdown.SelectByValue("2");

            dropdown = new SelectElement(staffpage.Detail);
            dropdown.SelectByText("Hide tasks");

            dropdown = new SelectElement(staffpage.FromMonth);
            dropdown.SelectByText("August");

            dropdown = new SelectElement(staffpage.FromDay);
            dropdown.SelectByValue("10");

            dropdown = new SelectElement(staffpage.FromYear);
            dropdown.SelectByValue("2015");

            staffpage.SetCurrentMonth.Click();

            dropdown = new SelectElement(staffpage.ToMonth);
            dropdown.SelectByText("April");

            dropdown = new SelectElement(staffpage.ToDay);
            dropdown.SelectByValue("2");

            dropdown = new SelectElement(staffpage.ToYear);
            dropdown.SelectByValue("2014");

            staffpage.SetCurrentWeek.Click();

            staffpage.MonthGreaterThan.Click();

            staffpage.MonthLessThan.Click();

            staffpage.WeekLessThan.Click();

            staffpage.ReportOnActiveCustomersAndProjectsOnly.Click();

            dropdown = new SelectElement(staffpage.Customer);
            dropdown.SelectByValue("21");

            dropdown = new SelectElement(staffpage.Project);
            dropdown.SelectByValue("4");

            staffpage.GenerateHTMLReport.Click();
        }

        [TestMethod]
        public void VerifyingClickOnSelectedStaffBySelectingFirstGroupByTaskNames()
        {
            LoginPageActions loginpageactions = new LoginPageActions(driver);
            loginpageactions.Login();

            navigation.ToStaffOutputReport();

            StaffOutputReportPagee staffpage = new StaffOutputReportPagee();
            PageFactory.InitElements(driver, staffpage);
            test.Log(LogStatus.Info, "Selected All Staff Successfully");
            staffpage.AllStaff.Click();

            //DropDown List 
            SelectElement dropdown = new SelectElement(staffpage.ResultByFirst);
            dropdown.SelectByValue("2");

            dropdown = new SelectElement(staffpage.groupBySecond);
            dropdown.SelectByValue("3");

            dropdown = new SelectElement(staffpage.Detail);
            dropdown.SelectByText("Hide tasks");

            dropdown = new SelectElement(staffpage.FromMonth);
            dropdown.SelectByText("August");

            dropdown = new SelectElement(staffpage.FromDay);
            dropdown.SelectByValue("10");

            dropdown = new SelectElement(staffpage.FromYear);
            dropdown.SelectByValue("2015");

            staffpage.SetCurrentMonth.Click();

            dropdown = new SelectElement(staffpage.ToMonth);
            dropdown.SelectByText("April");

            dropdown = new SelectElement(staffpage.ToDay);
            dropdown.SelectByValue("2");

            dropdown = new SelectElement(staffpage.ToYear);
            dropdown.SelectByValue("2014");

            staffpage.SetCurrentWeek.Click();

            staffpage.MonthGreaterThan.Click();

            staffpage.MonthLessThan.Click();

            staffpage.WeekLessThan.Click();

            staffpage.ReportOnActiveCustomersAndProjectsOnly.Click();

            dropdown = new SelectElement(staffpage.Customer);
            dropdown.SelectByValue("21");

            dropdown = new SelectElement(staffpage.Project);
            dropdown.SelectByValue("4");

            staffpage.GenerateHTMLReport.Click();
        }

        [TestMethod]
        public void VerifyingClickOnSelectedStaffBySelectingThenGroupByNothing()
        {
            LoginPageActions loginpageactions = new LoginPageActions(driver);
            loginpageactions.Login();

            navigation.ToStaffOutputReport();

            StaffOutputReportPagee staffpage = new StaffOutputReportPagee();
            PageFactory.InitElements(driver, staffpage);
            test.Log(LogStatus.Info, "Selected All Staff Successfully");
            staffpage.AllStaff.Click();

            //DropDown List 
            SelectElement dropdown = new SelectElement(staffpage.ResultByFirst);
            dropdown.SelectByValue("2");

            dropdown = new SelectElement(staffpage.groupBySecond);
            dropdown.SelectByValue("7");

            dropdown = new SelectElement(staffpage.Detail);
            dropdown.SelectByText("Hide tasks");

            dropdown = new SelectElement(staffpage.FromMonth);
            dropdown.SelectByText("August");

            dropdown = new SelectElement(staffpage.FromDay);
            dropdown.SelectByValue("10");

            dropdown = new SelectElement(staffpage.FromYear);
            dropdown.SelectByValue("2015");

            staffpage.SetCurrentMonth.Click();

            dropdown = new SelectElement(staffpage.ToMonth);
            dropdown.SelectByText("April");

            dropdown = new SelectElement(staffpage.ToDay);
            dropdown.SelectByValue("2");

            dropdown = new SelectElement(staffpage.ToYear);
            dropdown.SelectByValue("2014");

            staffpage.SetCurrentWeek.Click();

            staffpage.MonthGreaterThan.Click();

            staffpage.MonthLessThan.Click();

            staffpage.WeekLessThan.Click();

            staffpage.ReportOnActiveCustomersAndProjectsOnly.Click();

            dropdown = new SelectElement(staffpage.Customer);
            dropdown.SelectByValue("21");

            dropdown = new SelectElement(staffpage.Project);
            dropdown.SelectByValue("4");

            staffpage.GenerateHTMLReport.Click();
        }

        [TestMethod]
        public void VerifyingClickOnSelectedStaffBySelectingThenGroupByCustomer()
        {
            LoginPageActions loginpageactions = new LoginPageActions(driver);
            loginpageactions.Login();

            navigation.ToStaffOutputReport();

            StaffOutputReportPagee staffpage = new StaffOutputReportPagee();
            PageFactory.InitElements(driver, staffpage);
            test.Log(LogStatus.Info, "Selected All Staff Successfully");
            staffpage.AllStaff.Click();

            //DropDown List 
            SelectElement dropdown = new SelectElement(staffpage.ResultByFirst);
            dropdown.SelectByValue("2");

            dropdown = new SelectElement(staffpage.groupBySecond);
            dropdown.SelectByValue("7");

            dropdown = new SelectElement(staffpage.Detail);
            dropdown.SelectByText("Hide tasks");

            dropdown = new SelectElement(staffpage.FromMonth);
            dropdown.SelectByText("August");

            dropdown = new SelectElement(staffpage.FromDay);
            dropdown.SelectByValue("10");

            dropdown = new SelectElement(staffpage.FromYear);
            dropdown.SelectByValue("2015");

            staffpage.SetCurrentMonth.Click();

            dropdown = new SelectElement(staffpage.ToMonth);
            dropdown.SelectByText("April");

            dropdown = new SelectElement(staffpage.ToDay);
            dropdown.SelectByValue("2");

            dropdown = new SelectElement(staffpage.ToYear);
            dropdown.SelectByValue("2014");

            staffpage.SetCurrentWeek.Click();

            staffpage.MonthGreaterThan.Click();

            staffpage.MonthLessThan.Click();

            staffpage.WeekLessThan.Click();

            staffpage.ReportOnActiveCustomersAndProjectsOnly.Click();

            dropdown = new SelectElement(staffpage.Customer);
            dropdown.SelectByValue("21");

            dropdown = new SelectElement(staffpage.Project);
            dropdown.SelectByValue("4");

            staffpage.GenerateHTMLReport.Click();
        }

        [TestMethod]
        public void VerifyingClickOnSelectedStaffBySelectingThenGroupByProjects()
        {
            LoginPageActions loginpageactions = new LoginPageActions(driver);
            loginpageactions.Login();

            navigation.ToStaffOutputReport();

            StaffOutputReportPagee staffpage = new StaffOutputReportPagee();
            PageFactory.InitElements(driver, staffpage);
            test.Log(LogStatus.Info, "Selected All Staff Successfully");
            staffpage.AllStaff.Click();

            //DropDown List 
            SelectElement dropdown = new SelectElement(staffpage.ResultByFirst);
            dropdown.SelectByValue("2");

            dropdown = new SelectElement(staffpage.groupBySecond);
            dropdown.SelectByValue("5");

            dropdown = new SelectElement(staffpage.Detail);
            dropdown.SelectByText("Hide tasks");

            dropdown = new SelectElement(staffpage.FromMonth);
            dropdown.SelectByText("August");

            dropdown = new SelectElement(staffpage.FromDay);
            dropdown.SelectByValue("10");

            dropdown = new SelectElement(staffpage.FromYear);
            dropdown.SelectByValue("2015");

            staffpage.SetCurrentMonth.Click();

            dropdown = new SelectElement(staffpage.ToMonth);
            dropdown.SelectByText("April");

            dropdown = new SelectElement(staffpage.ToDay);
            dropdown.SelectByValue("2");

            dropdown = new SelectElement(staffpage.ToYear);
            dropdown.SelectByValue("2014");

            staffpage.SetCurrentWeek.Click();

            staffpage.MonthGreaterThan.Click();

            staffpage.MonthLessThan.Click();

            staffpage.WeekLessThan.Click();

            staffpage.ReportOnActiveCustomersAndProjectsOnly.Click();

            dropdown = new SelectElement(staffpage.Customer);
            dropdown.SelectByValue("21");

            dropdown = new SelectElement(staffpage.Project);
            dropdown.SelectByValue("4");

            staffpage.GenerateHTMLReport.Click();
        }

        [TestMethod]
        public void VerifyingClickOnSelectedStaffBySelectingThenGroupByProjectNames()
        {
            LoginPageActions loginpageactions = new LoginPageActions(driver);
            loginpageactions.Login();

            navigation.ToStaffOutputReport();

            StaffOutputReportPagee staffpage = new StaffOutputReportPagee();
            PageFactory.InitElements(driver, staffpage);
            test.Log(LogStatus.Info, "Selected All Staff Successfully");
            staffpage.AllStaff.Click();

            //DropDown List 
            SelectElement dropdown = new SelectElement(staffpage.ResultByFirst);
            dropdown.SelectByValue("2");

            dropdown = new SelectElement(staffpage.groupBySecond);
            dropdown.SelectByValue("8");

            dropdown = new SelectElement(staffpage.Detail);
            dropdown.SelectByText("Hide tasks");

            dropdown = new SelectElement(staffpage.FromMonth);
            dropdown.SelectByText("August");

            dropdown = new SelectElement(staffpage.FromDay);
            dropdown.SelectByValue("10");

            dropdown = new SelectElement(staffpage.FromYear);
            dropdown.SelectByValue("2015");

            staffpage.SetCurrentMonth.Click();

            dropdown = new SelectElement(staffpage.ToMonth);
            dropdown.SelectByText("April");

            dropdown = new SelectElement(staffpage.ToDay);
            dropdown.SelectByValue("2");

            dropdown = new SelectElement(staffpage.ToYear);
            dropdown.SelectByValue("2014");

            staffpage.SetCurrentWeek.Click();

            staffpage.MonthGreaterThan.Click();

            staffpage.MonthLessThan.Click();

            staffpage.WeekLessThan.Click();

            staffpage.ReportOnActiveCustomersAndProjectsOnly.Click();

            dropdown = new SelectElement(staffpage.Customer);
            dropdown.SelectByValue("21");

            dropdown = new SelectElement(staffpage.Project);
            dropdown.SelectByValue("4");

            staffpage.GenerateHTMLReport.Click();
        }

        [TestMethod]
        public void VerifyingClickOnSelectedStaffBySelectingThenGroupByBillingTypes()
        {
            LoginPageActions loginpageactions = new LoginPageActions(driver);
            loginpageactions.Login();

            navigation.ToStaffOutputReport();

            StaffOutputReportPagee staffpage = new StaffOutputReportPagee();
            PageFactory.InitElements(driver, staffpage);
            test.Log(LogStatus.Info, "Selected All Staff Successfully");
            staffpage.AllStaff.Click();

            //DropDown List 
            SelectElement dropdown = new SelectElement(staffpage.ResultByFirst);
            dropdown.SelectByValue("2");

            dropdown = new SelectElement(staffpage.groupBySecond);
            dropdown.SelectByValue("2");

            dropdown = new SelectElement(staffpage.Detail);
            dropdown.SelectByText("Hide tasks");

            dropdown = new SelectElement(staffpage.FromMonth);
            dropdown.SelectByText("August");

            dropdown = new SelectElement(staffpage.FromDay);
            dropdown.SelectByValue("10");

            dropdown = new SelectElement(staffpage.FromYear);
            dropdown.SelectByValue("2015");

            staffpage.SetCurrentMonth.Click();

            dropdown = new SelectElement(staffpage.ToMonth);
            dropdown.SelectByText("April");

            dropdown = new SelectElement(staffpage.ToDay);
            dropdown.SelectByValue("2");

            dropdown = new SelectElement(staffpage.ToYear);
            dropdown.SelectByValue("2014");

            staffpage.SetCurrentWeek.Click();

            staffpage.MonthGreaterThan.Click();

            staffpage.MonthLessThan.Click();

            staffpage.WeekLessThan.Click();

            staffpage.ReportOnActiveCustomersAndProjectsOnly.Click();

            dropdown = new SelectElement(staffpage.Customer);
            dropdown.SelectByValue("21");

            dropdown = new SelectElement(staffpage.Project);
            dropdown.SelectByValue("4");

            staffpage.GenerateHTMLReport.Click();
        }

        [TestMethod]
        public void VerifyingClickOnSelectedStaffBySelectingThenGroupByDates()
        {
            LoginPageActions loginpageactions = new LoginPageActions(driver);
            loginpageactions.Login();

            navigation.ToStaffOutputReport();

            StaffOutputReportPagee staffpage = new StaffOutputReportPagee();
            PageFactory.InitElements(driver, staffpage);
            test.Log(LogStatus.Info, "Selected All Staff Successfully");
            staffpage.AllStaff.Click();

            //DropDown List 
            SelectElement dropdown = new SelectElement(staffpage.ResultByFirst);
            dropdown.SelectByValue("2");

            dropdown = new SelectElement(staffpage.groupBySecond);
            dropdown.SelectByValue("3");

            dropdown = new SelectElement(staffpage.Detail);
            dropdown.SelectByText("Hide tasks");

            dropdown = new SelectElement(staffpage.FromMonth);
            dropdown.SelectByText("August");

            dropdown = new SelectElement(staffpage.FromDay);
            dropdown.SelectByValue("10");

            dropdown = new SelectElement(staffpage.FromYear);
            dropdown.SelectByValue("2015");

            staffpage.SetCurrentMonth.Click();

            dropdown = new SelectElement(staffpage.ToMonth);
            dropdown.SelectByText("April");

            dropdown = new SelectElement(staffpage.ToDay);
            dropdown.SelectByValue("2");

            dropdown = new SelectElement(staffpage.ToYear);
            dropdown.SelectByValue("2014");

            staffpage.SetCurrentWeek.Click();

            staffpage.MonthGreaterThan.Click();

            staffpage.MonthLessThan.Click();

            staffpage.WeekLessThan.Click();

            staffpage.ReportOnActiveCustomersAndProjectsOnly.Click();

            dropdown = new SelectElement(staffpage.Customer);
            dropdown.SelectByValue("21");

            dropdown = new SelectElement(staffpage.Project);
            dropdown.SelectByValue("4");

            staffpage.GenerateHTMLReport.Click();
        }


        //[TestMethod]
        //public void VerifyingClickOnSelectedStaffBySelectingHideTask()
        //{
        //    LoginPageActions loginpageactions = new LoginPageActions(driver);
        //    loginpageactions.Login();

        //    navigation.ToStaffOutputReport();

        //    StaffOutputReportPagee staffpage = new StaffOutputReportPagee();
        //    PageFactory.InitElements(driver, staffpage);
        //    test.Log(LogStatus.Info, "Selected All Staff Successfully");
        //    staffpage.AllStaff.Click();

        //    //DropDown List 
        //    SelectElement dropdown = new SelectElement(staffpage.ResultByFirst);
        //    dropdown.SelectByValue("9");

        //    dropdown = new SelectElement(staffpage.groupBySecond);
        //    dropdown.SelectByValue("5");

        //    dropdown = new SelectElement(staffpage.Detail);
        //    dropdown.SelectByValue("-6");

        //    dropdown = new SelectElement(staffpage.FromMonth);
        //    dropdown.SelectByText("August");

        //    dropdown = new SelectElement(staffpage.FromDay);
        //    dropdown.SelectByValue("10");

        //    dropdown = new SelectElement(staffpage.FromYear);
        //    dropdown.SelectByValue("2015");

        //    staffpage.SetCurrentMonth.Click();

        //    dropdown = new SelectElement(staffpage.ToMonth);
        //    dropdown.SelectByText("April");

        //    dropdown = new SelectElement(staffpage.ToDay);
        //    dropdown.SelectByValue("2");

        //    dropdown = new SelectElement(staffpage.ToYear);
        //    dropdown.SelectByValue("2014");

        //    staffpage.SetCurrentWeek.Click();

        //    staffpage.MonthGreaterThan.Click();

        //    staffpage.MonthLessThan.Click();

        //    staffpage.WeekLessThan.Click();

        //    staffpage.ReportOnActiveCustomersAndProjectsOnly.Click();

        //    dropdown = new SelectElement(staffpage.Customer);
        //    dropdown.SelectByValue("21");

        //    dropdown = new SelectElement(staffpage.Project);
        //    dropdown.SelectByValue("4");

        //    staffpage.GenerateHTMLReport.Click();
        //}

        [TestMethod]
        public void VerifyingClickOnSelectedStaffBySelectingShowTaskDetails()
        {
            LoginPageActions loginpageactions = new LoginPageActions(driver);
            loginpageactions.Login();

            navigation.ToStaffOutputReport();

            StaffOutputReportPagee staffpage = new StaffOutputReportPagee();
            PageFactory.InitElements(driver, staffpage);
            test.Log(LogStatus.Info, "Selected All Staff Successfully");
            staffpage.AllStaff.Click();

            //DropDown List 
            SelectElement dropdown = new SelectElement(staffpage.ResultByFirst);
            dropdown.SelectByValue("2");

            dropdown = new SelectElement(staffpage.groupBySecond);
            dropdown.SelectByValue("7");

            dropdown = new SelectElement(staffpage.Detail);
            dropdown.SelectByText("Show tasks");

            dropdown = new SelectElement(staffpage.FromMonth);
            dropdown.SelectByText("August");

            dropdown = new SelectElement(staffpage.FromDay);
            dropdown.SelectByValue("10");

            dropdown = new SelectElement(staffpage.FromYear);
            dropdown.SelectByValue("2015");

            staffpage.SetCurrentMonth.Click();

            dropdown = new SelectElement(staffpage.ToMonth);
            dropdown.SelectByText("April");

            dropdown = new SelectElement(staffpage.ToDay);
            dropdown.SelectByValue("2");

            dropdown = new SelectElement(staffpage.ToYear);
            dropdown.SelectByValue("2014");

            staffpage.SetCurrentWeek.Click();

            staffpage.MonthGreaterThan.Click();

            staffpage.MonthLessThan.Click();

            staffpage.WeekLessThan.Click();

            staffpage.ReportOnActiveCustomersAndProjectsOnly.Click();

            dropdown = new SelectElement(staffpage.Customer);
            dropdown.SelectByValue("21");

            dropdown = new SelectElement(staffpage.Project);
            dropdown.SelectByValue("4");

            staffpage.GenerateHTMLReport.Click();
        }

    }
}
