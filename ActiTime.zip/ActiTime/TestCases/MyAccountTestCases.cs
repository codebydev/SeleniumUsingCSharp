﻿using ActiTime.PageActions;
using ActiTime.Pages;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ActiTime.TestCases
{
    [TestClass]
   public class MyAccountTestCases:TestBase
    {
        [TestMethod]
        public void AccountWithValidValues()
        {
            LoginPageActions loginpageactions = new LoginPageActions(driver);
            loginpageactions.Login();

            navigation.ToMyAccount();
            MyAccount AccountPage = new MyAccount();
            PageFactory.InitElements(driver, AccountPage);
            AccountPage.CustomerPassword.SendKeys("abc");
            AccountPage.NewPassword.SendKeys("manager");
            AccountPage.RetypePassword.SendKeys("manager");
            AccountPage.FirstName.SendKeys("ABCD");
            AccountPage.LastName.SendKeys("EF");
            AccountPage.MiddleInitial.SendKeys("G");
            AccountPage.Phone.SendKeys("53088");
            AccountPage.Fax.SendKeys("000");
            AccountPage.Mobile.SendKeys("90359300000");
            AccountPage.EmailAddress.SendKeys("ram@gmail.com");
            AccountPage.OtherContact.SendKeys("302023033");
            AccountPage.SaveChanges.Click();

        }

        [TestMethod]
        public void VerifyingWithoutGamil()
        {
            LoginPageActions loginpageactions = new LoginPageActions(driver);
            loginpageactions.Login();

            navigation.ToMyAccount();
            MyAccount AccountPage = new MyAccount();
            PageFactory.InitElements(driver, AccountPage);
            AccountPage.CustomerPassword.SendKeys("abc");
            AccountPage.NewPassword.SendKeys("manager");
            AccountPage.RetypePassword.SendKeys("manager");
            AccountPage.FirstName.SendKeys("ABCD");
            AccountPage.LastName.SendKeys("EF");
            AccountPage.MiddleInitial.SendKeys("G");
            AccountPage.Phone.SendKeys("53088");
            AccountPage.Fax.SendKeys("000");
            AccountPage.Mobile.SendKeys("90359300000");
            AccountPage.EmailAddress.SendKeys("");
            AccountPage.OtherContact.SendKeys("302023033");
            AccountPage.SaveChanges.Click();

        }
    }
}
