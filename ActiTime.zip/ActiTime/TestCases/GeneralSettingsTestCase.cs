﻿using ActiTime.PageActions;
using ActiTime.Pages;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ActiTime.TestCases
{
    [TestClass]
   public class GeneralSettingsTestCase:TestBase
    {
        [TestMethod]
        public void VerfyingTheClickOnTopLevelCustomer()
        {
            LoginPageActions loginpageaction = new LoginPageActions(driver);
            loginpageaction.Login();

            navigation.ToGeneralSettings();

            GeneralSettingsPage generalpage = new GeneralSettingsPage();
            PageFactory.InitElements(driver, generalpage);

            SelectElement dropdown = new SelectElement(generalpage.TopLevel);
            dropdown.SelectByValue("2");

           dropdown = new SelectElement(generalpage.MiddleLevel);
           dropdown.SelectByValue("6");

           dropdown = new SelectElement(generalpage.LowestLevel);
           dropdown.SelectByValue("11");

           dropdown = new SelectElement(generalpage.DateFormat);
           dropdown.SelectByValue("MMM dd, yy");

           dropdown = new SelectElement(generalpage.CalendarLayout);
           dropdown.SelectByValue("US");

           dropdown = new SelectElement(generalpage.Unlimited);
           dropdown.SelectByValue("false");

           dropdown = new SelectElement(generalpage.MaximumHoursPerDay);
           dropdown.SelectByValue("90");

           dropdown = new SelectElement(generalpage.Collectovertimeonly);
           dropdown.SelectByValue("overtime");

           dropdown = new SelectElement(generalpage.SupportinternationalcharactersCSVreportsusepredefinedfieldseparator);
           dropdown.SelectByValue("true");

           dropdown = new SelectElement(generalpage.DefaultWorkdayDuration);
           dropdown.SelectByValue("180");

           generalpage.SaveSettings.Click();
        }
    }
}
