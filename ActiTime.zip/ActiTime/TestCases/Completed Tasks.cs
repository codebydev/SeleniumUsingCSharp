﻿using ActiTime.PageActions;
using ActiTime.Pages.ProjectsAndTasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RelevantCodes.ExtentReports;
using OpenQA.Selenium.Support.UI;

namespace ActiTime.TestCases
{
    [TestClass]
    public class Completed_Tasks : TestBase
    {
        [TestMethod]
        public void verifycompletedtasks()
        {

            LoginPageActions loginpageactions = new LoginPageActions(driver);
            loginpageactions.Login();
            navigation.ToCompletedTasks();
            CompletedTasks ct = new CompletedTasks();
            PageFactory.InitElements(driver, ct);
            test.Log(LogStatus.Info, "Verify the Whether user is able to select the the customer");
            ct.Customer.Click();
            SelectElement se = new SelectElement(ct.Customer);
            se.SelectByValue("1");

            se = new SelectElement(ct.Customer1);
            se.SelectByValue("1");

            se = new SelectElement(ct.Month);
            se.SelectByValue("7");

            se = new SelectElement(ct.Day);
            se.SelectByValue("11");

            se = new SelectElement(ct.Year);
            se.SelectByValue("2015");

            se = new SelectElement(ct.Month1);
            se.SelectByValue("7");

            se = new SelectElement(ct.Day1);
            se.SelectByValue("11");

            se = new SelectElement(ct.Year1);
            se.SelectByValue("2015");

           // ct.Label.Text;
            ct.ShowTasks.Click();
            ct.CleaeDates.Click();

            // 1. create a customer
            // 2. create a project
            // 3. create a task
            // 4. 
        }
    [TestMethod]
      public void FunctionalityOfClearDates()
      {
          LoginPageActions loginpageactions = new LoginPageActions(driver);
          loginpageactions.Login();
          navigation.ToCompletedTasks();
          CompletedTasks ct = new CompletedTasks();
          PageFactory.InitElements(driver, ct);
          ct.Customer.Click();
          ct.Customer1.Click();
          SelectElement dropdown = new SelectElement(ct.Customer);
          dropdown.SelectByValue("1");

          dropdown = new SelectElement(ct.Customer1);
          dropdown.SelectByValue("1");

          dropdown = new SelectElement(ct.Month);
          dropdown.SelectByValue("7");

          dropdown = new SelectElement(ct.Day);
          dropdown.SelectByValue("11");

          dropdown = new SelectElement(ct.Year);
          dropdown.SelectByValue("2015");

          dropdown = new SelectElement(ct.Month1);
          dropdown.SelectByValue("7");

          dropdown = new SelectElement(ct.Day1);
          dropdown.SelectByValue("11");

          dropdown = new SelectElement(ct.Year1);
          dropdown.SelectByValue("2011");
          ct.CleaeDates.Click();
          
        
          
      } 
        [TestMethod]
      public void verifythemessage()
      {
          LoginPageActions loginpageactions = new LoginPageActions(driver);
          loginpageactions.Login();
          navigation.ToCompletedTasks();
          CompletedTasks ct = new CompletedTasks();
          PageFactory.InitElements(driver, ct);
          ct.ShowTasks.Click();
          //string actual = ct.Message.Text;
          //Assert.IsTrue(actual.Contains("There are no completed tasks found."));
      }
        [TestMethod]
        public void VerifyTheErrorMessage1()
        {
            LoginPageActions loginpageactions = new LoginPageActions(driver);
            loginpageactions.Login();
            navigation.ToCompletedTasks();
            CompletedTasks ct = new CompletedTasks();
            PageFactory.InitElements(driver, ct);
            ct.Customer.Click();
            ct.Customer1.Click();
            SelectElement dropdown = new SelectElement(ct.Customer);
            dropdown.SelectByValue("1");
            dropdown = new SelectElement(ct.Customer1);
            dropdown.SelectByValue("1");

           

            dropdown = new SelectElement(ct.Year);
            dropdown.SelectByValue("2015");

            dropdown = new SelectElement(ct.Month1);
            dropdown.SelectByValue("7");

           

            dropdown = new SelectElement(ct.Year1);
            dropdown.SelectByValue("2011");
            ct.ShowTasks.Click();
            string actual = ct.ErrorMessage.Text;
            Assert.IsTrue(actual.Contains("The \"Completion Date\" filter was not applied. The following fields are invalid: From Month, From Day of month, To Day of month"));
           




        }
        [TestMethod]
        public void VerifyTheErorrMesage2()
        {
            LoginPageActions loginpageactions = new LoginPageActions(driver);
            loginpageactions.Login();
            navigation.ToCompletedTasks();
           // PageFactory.InitElements(driver, loginpageactions);
           // CompletedTasks ct = new CompletedTasks();
            CompletedTasks ct1 = new CompletedTasks();
            PageFactory.InitElements(driver, ct1);
           // CompletedTasks ct1 = new CompletedTasks();
            ct1.Customer.Click();
            ct1.Customer1.Click();
            SelectElement dropdown = new SelectElement(ct1.Customer);
            dropdown.SelectByValue("1");
            dropdown = new SelectElement(ct1.Customer1);
            dropdown.SelectByValue("1");



            dropdown = new SelectElement(ct1.Year);
            dropdown.SelectByValue("2015");

            dropdown = new SelectElement(ct1.Month1);
            dropdown.SelectByValue("7");

            dropdown = new SelectElement(ct1.Year1);
            dropdown.SelectByValue("2011");
            ct1.ShowTasks.Click();
            string actual = ct1.InvalidMessage.Text;
            Assert.IsTrue(actual.Contains("The \"Completion Date\" filter was not applied. The following fields are invalid: From Month, From Day of month, To Day of month"));
           
            

        }
    }
}
   

