﻿using ActiTime.Pages;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium.Support.PageObjects;
using RelevantCodes.ExtentReports;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ActiTime.TestCases
{
    [TestClass]
    public class LoginPageTestCases:TestBase
    {
        [TestMethod]
        public void VerifyLoginWithValidUserNameAndPassword()
        {

            LoginPage loginpage = new LoginPage();

            PageFactory.InitElements(driver, loginpage);
            test.Log(LogStatus.Info, "Launced Acttime Login Page sucessufully");
            loginpage.UserName.SendKeys("admin");
            test.Log(LogStatus.Info, "Enterd the UserName as admin in username text field");
            loginpage.PassWord.SendKeys("manager");
            test.Log(LogStatus.Info, "Enterd the Password as manager in password text field");
            loginpage.LoginNow.Click();
            test.Log(LogStatus.Info, "Click Event Done on LoginNow button");
            test.Log(LogStatus.Pass, "Executed all the test cases");
        }
 

        [TestMethod]
        public void VerifyLoginWithValidUserNameAndInvalidPassword()
        {

            LoginPage loginpage = new LoginPage();

            PageFactory.InitElements(driver, loginpage);
            test.Log(LogStatus.Info, "Launced Acttime Login Page sucessufully");
            loginpage.UserName.SendKeys("admin");
            test.Log(LogStatus.Info, "Enterd the UserName as admin in username text field");
            loginpage.PassWord.SendKeys("katti");
            test.Log(LogStatus.Info, "Enterd the invalid Password as manager in password text field");
            loginpage.LoginNow.Click();
            test.Log(LogStatus.Info, "Click Event Done on LoginNow button");
			Thread.Sleep(2000);
			string actual = loginpage.ErrorMessage.Text;
            Assert.AreEqual("Username or Password is invalid. Please try again.", actual);
            test.Log(LogStatus.Pass, "Executed all the test cases");
        }

        [TestMethod]
        public void VerifyLoginInvalidUserNameAndValidPassword()
        {
            LoginPage loginpage = new LoginPage();

            PageFactory.InitElements(driver, loginpage);
            test.Log(LogStatus.Info, "Launced Acttime Login Page sucessufully");
            loginpage.UserName.SendKeys("abc");
            test.Log(LogStatus.Info, "Enterd the invalid UserName as admin in username text field");
            loginpage.PassWord.SendKeys("manager");
            test.Log(LogStatus.Info, "Enterd the Password as manager in password text field");
            loginpage.LoginNow.Click();
            test.Log(LogStatus.Info, "Click Event Done on LoginNow button");
			Thread.Sleep(2000);
			string actual = loginpage.ErrorMessage.Text;
            Assert.AreEqual("Username or Password is invalid. Please try again.", actual);
            test.Log(LogStatus.Pass, "Executed all the test cases");
        }

        [TestMethod]
        public void VerifyLoginInvalidUserNameAndInValidPassword()
        {
            LoginPage loginpage = new LoginPage();

            PageFactory.InitElements(driver, loginpage);
            test.Log(LogStatus.Info, "Launced Acttime Login Page sucessufully");
            loginpage.UserName.SendKeys("abc");
            test.Log(LogStatus.Info, "Enterd the invalid UserName as admin in username text field");
            loginpage.PassWord.SendKeys("katti");
            test.Log(LogStatus.Info, "Enterd the invalid Password as manager in password text field");
            loginpage.LoginNow.Click();
            test.Log(LogStatus.Info, "Click Event Done on LoginNow button");
			Thread.Sleep(2000);
			string actual = loginpage.ErrorMessage.Text;
            Assert.AreEqual("Username or Password is invalid. Please try again.", actual);
            test.Log(LogStatus.Pass, "Executed all the test cases");
        }


        [TestMethod]
        public void VerifyLoginWithoutPassword()
        {
            LoginPage loginpage = new LoginPage();

            PageFactory.InitElements(driver, loginpage);
            test.Log(LogStatus.Info, "Launced Acttime Login Page sucessufully");
            loginpage.UserName.SendKeys("admin");
            test.Log(LogStatus.Info, "Enterd the UserName as admin in username text field");
            //loginpage.PassWord.SendKeys("katti");
            //test.Log(LogStatus.Info, "Enterd the invalid Password as manager in password text field");
            loginpage.LoginNow.Click();
            test.Log(LogStatus.Info, "Click Event Done on LoginNow button");
			Thread.Sleep(2000);
			string actual = loginpage.ErrorMessage.Text;
            Assert.AreEqual("Username or Password is invalid. Please try again.", actual);
            test.Log(LogStatus.Pass, "Executed all the test cases");
        }

        [TestMethod]
        public void VerifyLoginWithoutUsernameAndWithValidPassword()
        {
            LoginPage loginpage = new LoginPage();

            PageFactory.InitElements(driver, loginpage);
            test.Log(LogStatus.Info, "Launced Acttime Login Page sucessufully");
            //loginpage.UserName.SendKeys("admin");
            //test.Log(LogStatus.Info, "Enterd the UserName as admin in username text field");
            loginpage.PassWord.SendKeys("katti");
            test.Log(LogStatus.Info, "Enterd the invalid Password as manager in password text field");
            loginpage.LoginNow.Click();
            test.Log(LogStatus.Info, "Click Event Done on LoginNow button");
			Thread.Sleep(2000);
			string actual = loginpage.ErrorMessage.Text;
            Assert.AreEqual("Username or Password is invalid. Please try again.", actual);
            test.Log(LogStatus.Pass, "Executed all the test cases");
        }

        [TestMethod]
        public void VerifyLoginWithoutCredentials()
        {
            LoginPage loginpage = new LoginPage();

            PageFactory.InitElements(driver, loginpage);
            test.Log(LogStatus.Info, "Launced Acttime Login Page sucessufully");
            //loginpage.UserName.SendKeys("admin");
            test.Log(LogStatus.Info, "Skipped to enter UserName");
            //loginpage.PassWord.SendKeys("katti");
            test.Log(LogStatus.Info, "Skipped to enter Password");
            loginpage.LoginNow.Click();
            test.Log(LogStatus.Info, "Click Event Done on LoginNow button");
			Thread.Sleep(2000);
			string actual = loginpage.ErrorMessage.Text;
            Assert.AreEqual("Username or Password is invalid. Please try again.", actual);
            test.Log(LogStatus.Pass, "Executed all the test cases");
        }

        [TestMethod]
        public void Dummy()
        {
            LoginPage loginPage = new LoginPage();

            PageFactory.InitElements(driver, loginPage);
            loginPage.UserName.SendKeys("admin");
            loginPage.PassWord.SendKeys("manager");
            loginPage.LoginNow.Click();

            navigation.ToOpenTasks();


            navigation.ToProjectsAndCustomers();
            navigation.ToArchives();
            navigation.ToCompletedTasks();
            navigation.ToOpenTasks();
           
            navigation.ToBillingSummaryReport();
            navigation.ToOvertimeReport();
            navigation.ToStaffOutputReport();
            navigation.ToPrepareInvoiceData();
        }

    }
}
