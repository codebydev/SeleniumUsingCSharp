﻿using ActiTime.PageActions;
using ActiTime.Pages.Reports;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ActiTime.TestCases
{
	[TestClass]
	public class OverTimeReportPageTestCases:TestBase
	{
		[TestMethod]
		public void OverTimeReportGenerateWithValidValues()
		{
			LoginPageActions loginPageActions = new LoginPageActions(driver);
			loginPageActions.Login();
			navigation.ToOvertimeReport();

			OverTimeReportPage overTimeReportPage = new OverTimeReportPage();
			PageFactory.InitElements(driver, overTimeReportPage);
			overTimeReportPage.Users_all.Click();

			overTimeReportPage.FirstLevel.Click();
			SelectElement selectDropDown = new SelectElement(overTimeReportPage.FirstLevel);
			selectDropDown.SelectByValue("2");

			SelectElement selectDropDown1 = new SelectElement(overTimeReportPage.SecondLevel);
			selectDropDown1.SelectByValue("2");

			SelectElement SelectDropDownFromMonth = new SelectElement(overTimeReportPage.FromMonth);
			SelectDropDownFromMonth.SelectByValue("1");

			SelectElement SelectDropDownFromDay = new SelectElement(overTimeReportPage.FromDay);
			SelectDropDownFromDay.SelectByValue("2");

			SelectElement SelectDropDownFromYear = new SelectElement(overTimeReportPage.FromYear);
			SelectDropDownFromYear.SelectByValue("2011");

			SelectElement SelectDropDownToMonth = new SelectElement(overTimeReportPage.ToMonth);
			SelectDropDownToMonth.SelectByValue("2");

			SelectElement SelectDropDownToDay = new SelectElement(overTimeReportPage.ToDay);
			SelectDropDownToDay.SelectByValue("4");

			SelectElement SelectDropDownToYear = new SelectElement(overTimeReportPage.ToYear);
			SelectDropDownToYear.SelectByValue("2009");

			overTimeReportPage.Month.Click();
			overTimeReportPage.Week1.Click();

			overTimeReportPage.Generate_HTML_Report.Click();

		}


		[TestMethod]
		public void OverTimeReportGenerateWithInvalidValues()
		{
			LoginPageActions loginPageActions = new LoginPageActions(driver);
			loginPageActions.Login();
			navigation.ToOvertimeReport();

			OverTimeReportPage overTimeReportPage = new OverTimeReportPage();
			PageFactory.InitElements(driver, overTimeReportPage);
			overTimeReportPage.users_selected.Click();

			overTimeReportPage.FirstLevel.Click();
			SelectElement selectDropDown = new SelectElement(overTimeReportPage.FirstLevel);
			selectDropDown.SelectByValue("1");

			SelectElement selectDropDown1 = new SelectElement(overTimeReportPage.SecondLevel);
			selectDropDown1.SelectByValue("2");

			SelectElement SelectDropDownFromMonth = new SelectElement(overTimeReportPage.FromMonth);
			SelectDropDownFromMonth.SelectByValue("2");

			SelectElement SelectDropDownFromDay = new SelectElement(overTimeReportPage.FromDay);
			Thread.Sleep(1000);
			SelectDropDownFromDay.SelectByValue("5");

			SelectElement SelectDropDownFromYear = new SelectElement(overTimeReportPage.FromYear);
			SelectDropDownFromYear.SelectByValue("2013");

			SelectElement SelectDropDownToMonth = new SelectElement(overTimeReportPage.ToMonth);
			SelectDropDownToMonth.SelectByValue("2");

			SelectElement SelectDropDownToDay = new SelectElement(overTimeReportPage.ToDay);
			SelectDropDownToDay.SelectByValue("4");

			SelectElement SelectDropDownToYear = new SelectElement(overTimeReportPage.ToYear);
			SelectDropDownToYear.SelectByValue("2009");

			overTimeReportPage.Month.Click();
			overTimeReportPage.Week1.Click();

			overTimeReportPage.Generate_HTML_Report.Click();

		}

		[TestMethod]
		public void OverTimeReportGenerateWithValidValues_2()
		{
			LoginPageActions loginPageActions = new LoginPageActions(driver);
			loginPageActions.Login();
			navigation.ToOvertimeReport();

			OverTimeReportPage overTimeReportPage = new OverTimeReportPage();
			PageFactory.InitElements(driver, overTimeReportPage);
			overTimeReportPage.users_selected.Click();

			overTimeReportPage.FirstLevel.Click();
			SelectElement selectDropDown = new SelectElement(overTimeReportPage.FirstLevel);
			selectDropDown.SelectByValue("1");

			SelectElement selectDropDown1 = new SelectElement(overTimeReportPage.SecondLevel);
			selectDropDown1.SelectByValue("2");

			SelectElement SelectDropDownFromMonth = new SelectElement(overTimeReportPage.FromMonth);
			SelectDropDownFromMonth.SelectByValue("2");

			SelectElement SelectDropDownFromDay = new SelectElement(overTimeReportPage.FromDay);
			Thread.Sleep(1000);
			SelectDropDownFromDay.SelectByValue("5");

			SelectElement SelectDropDownFromYear = new SelectElement(overTimeReportPage.FromYear);
			Thread.Sleep(5000);
			SelectDropDownFromYear.SelectByValue("3020");
			Thread.Sleep(5000);
			SelectElement SelectDropDownToMonth = new SelectElement(overTimeReportPage.ToMonth);
			Thread.Sleep(1000);
			SelectDropDownToMonth.SelectByValue("2");

			SelectElement SelectDropDownToDay = new SelectElement(overTimeReportPage.ToDay);
			SelectDropDownToDay.SelectByValue("4");

			SelectElement SelectDropDownToYear = new SelectElement(overTimeReportPage.ToYear);
			SelectDropDownToYear.SelectByValue("2009");

			overTimeReportPage.Month.Click();
			overTimeReportPage.Week1.Click();
			Thread.Sleep(5000);
			overTimeReportPage.Generate_HTML_Report.Click();
			Thread.Sleep(5000);
		}

		[TestMethod]
		public void OverTimeReportGenerateWithInvalidDates()
		{
			LoginPageActions loginPageActions = new LoginPageActions(driver);
			loginPageActions.Login();
			navigation.ToOvertimeReport();

			OverTimeReportPage overTimeReportPage = new OverTimeReportPage();
			PageFactory.InitElements(driver, overTimeReportPage);
			overTimeReportPage.users_selected.Click();

			overTimeReportPage.FirstLevel.Click();
			SelectElement selectDropDown = new SelectElement(overTimeReportPage.FirstLevel);
			selectDropDown.SelectByValue("1");

			SelectElement selectDropDown1 = new SelectElement(overTimeReportPage.SecondLevel);
			selectDropDown1.SelectByValue("2");

			SelectElement SelectDropDownFromMonth = new SelectElement(overTimeReportPage.FromMonth);
			SelectDropDownFromMonth.SelectByValue("1");

			SelectElement SelectDropDownFromDay = new SelectElement(overTimeReportPage.FromDay);
			Thread.Sleep(1000);
			SelectDropDownFromDay.SelectByValue("15");

			SelectElement SelectDropDownFromYear = new SelectElement(overTimeReportPage.FromYear);
			SelectDropDownFromYear.SelectByValue("2011");

			SelectElement SelectDropDownToMonth = new SelectElement(overTimeReportPage.ToMonth);
			SelectDropDownToMonth.SelectByValue("2");

			SelectElement SelectDropDownToDay = new SelectElement(overTimeReportPage.ToDay);
			SelectDropDownToDay.SelectByValue("4");

			SelectElement SelectDropDownToYear = new SelectElement(overTimeReportPage.ToYear);
			SelectDropDownToYear.SelectByValue("2009");

			overTimeReportPage.Month.Click();
			overTimeReportPage.Week1.Click();
			Thread.Sleep(5000);
			overTimeReportPage.Generate_HTML_Report.Click();
			Thread.Sleep(5000);
		}
	}
}
