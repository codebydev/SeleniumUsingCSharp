﻿using ActiTime.PageActions;
using ActiTime.Pages.Settings;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ActiTime.TestCases
{
    [TestClass]
    public class BillingTypes : TestBase
    {
        [TestMethod]
        public void VerifyTheBillableBehavior1()
        {
            LoginPageActions loginpageaction = new LoginPageActions(driver);
            loginpageaction.Login();

            navigation.ToBillingTypes();
            BillingTypesPage billingtypespage = new BillingTypesPage();
            PageFactory.InitElements(driver, billingtypespage);
            billingtypespage.Billing.Click();
            billingtypespage.Savechanges.Click();
            string actual = billingtypespage.SucceesMessage.Text;
            Assert.IsTrue(actual.Contains("Your changes have been saved."));


        }

        [TestMethod]
        public void VerifytheModifiactionMessage()
        {
            LoginPageActions loginpageaction = new LoginPageActions(driver);
            loginpageaction.Login();

            navigation.ToBillingTypes();
            BillingTypesPage billingtypespage = new BillingTypesPage();
            PageFactory.InitElements(driver, billingtypespage);
            billingtypespage.Billing.Click();
            billingtypespage.Billable.Clear();
            billingtypespage.Savechanges.Click();
            string actual = billingtypespage.ModifiedMessage1.Text;
            Assert.IsTrue(actual.Contains("MODIFICATIONS NOT SAVED"));


        }
        [TestMethod]
        public void VerifyNoteMessage()
        {
            LoginPageActions loginpageactions = new LoginPageActions(driver);
            loginpageactions.Login();
            navigation.ToBillingTypes();
            BillingTypesPage billingtypespage=new BillingTypesPage();
            PageFactory.InitElements(driver, billingtypespage);
            string actual = billingtypespage.NoteMessage.Text;
            Assert.IsTrue(actual.Contains("\"Non-Billable\" billing type is a mandatory element of the system. It cannot be removed or modified."));


        }
        [TestMethod]
        public void FunctionalityofDeletButton()
        {
            LoginPageActions loginpageactions = new LoginPageActions(driver);
            loginpageactions.Login();
            navigation.ToBillingTypes();
            BillingTypesPage billingtypespage = new BillingTypesPage();
            PageFactory.InitElements(driver, billingtypespage);
            billingtypespage.Delete.Click();
            driver.SwitchTo().Alert().Accept();


        }
        [TestMethod]
        public void FunctionalityofDeletButton1()
        {
            LoginPageActions loginpageactions = new LoginPageActions(driver);
            loginpageactions.Login();
            navigation.ToBillingTypes();
            BillingTypesPage billingtypespage = new BillingTypesPage();
            PageFactory.InitElements(driver, billingtypespage);
            billingtypespage.AddNewBillingType1.Click();
            billingtypespage.Billing1.SendKeys("Ram");
            billingtypespage.Create.Click();



        }
    }
}
