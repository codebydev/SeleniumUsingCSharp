﻿using ActiTime.PageActions;
using ActiTime.Pages.Reports;
using ActiTime.Pages.Reports.OverTimeReport;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ActiTime.TestCases
{
	[TestClass]
	public class GenerateHTMLReportPageTestCases:TestBase
	{
		[TestMethod]
		public void GenerateHtmlReportForchangeReportPage()
		{
			LoginPageActions loginPageActions = new LoginPageActions(driver);
			loginPageActions.Login();
			navigation.ToOvertimeReport();

			OverTimeReportPage overTimeReportPage = new OverTimeReportPage();
			PageFactory.InitElements(driver, overTimeReportPage);
			overTimeReportPage.Generate_HTML_Report.Click();

			GenerateHTMLReportPage generateHTMLReportPage = new GenerateHTMLReportPage();
			PageFactory.InitElements(driver, generateHTMLReportPage);
			Thread.Sleep(1000);
			generateHTMLReportPage.Change_report_Parameter.Click();
			Thread.Sleep(1000);
			overTimeReportPage.Generate_HTML_Report.Click();

		}
		[TestMethod]
		public void GenerateHtmlReportForExportToCSVFormat()
		{
			LoginPageActions loginPageActions = new LoginPageActions(driver);
			loginPageActions.Login();
			navigation.ToOvertimeReport();

			OverTimeReportPage overTimeReportPage = new OverTimeReportPage();
			PageFactory.InitElements(driver, overTimeReportPage);
			overTimeReportPage.Generate_HTML_Report.Click();

			GenerateHTMLReportPage generateHTMLReportPage = new GenerateHTMLReportPage();
			PageFactory.InitElements(driver, generateHTMLReportPage);
			generateHTMLReportPage.Export_to_CSV_format.Click();
		}
	}
}
