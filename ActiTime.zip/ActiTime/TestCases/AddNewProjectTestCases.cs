﻿using ActiTime.PageActions;
using ActiTime.Pages.ProjectsAndTasks;
using ActiTime.Pages.ProjectsAndTasks.ProjectAndCustomers;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ActiTime.TestCases
{
    [TestClass]
    public class AddNewProjectTestCases: TestBase
    {

        [TestMethod]
        public void AddNewProject1()
        {

            LoginPageActions loginPageActions = new LoginPageActions(driver);
            loginPageActions.Login();
            navigation.ToProjectsAndCustomers();

            ProjectsAndCutomer projectsAndCutomer = new ProjectsAndCutomer();
            PageFactory.InitElements(driver, projectsAndCutomer);
            projectsAndCutomer.AddNewProject.Click();

            AddNewProjectPage addNewProjectPage = new AddNewProjectPage();
            PageFactory.InitElements(driver, addNewProjectPage);
            addNewProjectPage.Customer.Click();
            SelectElement selectDropDown = new SelectElement(addNewProjectPage.Customer);
            selectDropDown.SelectByValue("1");
            Thread.Sleep(1000);

            addNewProjectPage.ProjectName.SendKeys("abc-1");
            addNewProjectPage.CustomerDescription.SendKeys("Adding first new project");
            addNewProjectPage.ShowList.Click();
            addNewProjectPage.create_project_submit.Click();           

        }

        [TestMethod]
        public void AddNewProjectWithSecondCustomer()
        {

            LoginPageActions loginPageActions = new LoginPageActions(driver);
            loginPageActions.Login();
            navigation.ToProjectsAndCustomers();

            ProjectsAndCutomer projectsAndCutomer = new ProjectsAndCutomer();
            PageFactory.InitElements(driver, projectsAndCutomer);
            projectsAndCutomer.AddNewProject.Click();

            AddNewProjectPage addNewProjectPage = new AddNewProjectPage();
            PageFactory.InitElements(driver, addNewProjectPage);
            addNewProjectPage.Customer.Click();
            SelectElement selectDropDown = new SelectElement(addNewProjectPage.Customer);
            selectDropDown.SelectByValue("2");
            Thread.Sleep(1000);

            addNewProjectPage.ProjectName.SendKeys("abc-2");
            addNewProjectPage.CustomerDescription.SendKeys("Adding Second new project");
            addNewProjectPage.ShowList.Click();
            addNewProjectPage.create_project_submit.Click();

        }

        [TestMethod]
        public void AddNewProjectSelectSecondRadiobutton()
        {

            LoginPageActions loginPageActions = new LoginPageActions(driver);
            loginPageActions.Login();
            navigation.ToProjectsAndCustomers();

            ProjectsAndCutomer projectsAndCutomer = new ProjectsAndCutomer();
            PageFactory.InitElements(driver, projectsAndCutomer);
            projectsAndCutomer.AddNewProject.Click();

            AddNewProjectPage addNewProjectPage = new AddNewProjectPage();
            PageFactory.InitElements(driver, addNewProjectPage);
            addNewProjectPage.Customer.Click();
            SelectElement selectDropDown = new SelectElement(addNewProjectPage.Customer);
            selectDropDown.SelectByValue("1");
           
            addNewProjectPage.ProjectName.SendKeys("abc-3");
            addNewProjectPage.CustomerDescription.SendKeys("Adding third new project");
            addNewProjectPage.add_tasks_to_this_project.Click();
            addNewProjectPage.create_project_submit.Click();

        }

        [TestMethod]
        public void AddNewProjectSelectSecondRadiobutton2()
        {

            LoginPageActions loginPageActions = new LoginPageActions(driver);
            loginPageActions.Login();
            navigation.ToProjectsAndCustomers();

            ProjectsAndCutomer projectsAndCutomer = new ProjectsAndCutomer();
            PageFactory.InitElements(driver, projectsAndCutomer);
            projectsAndCutomer.AddNewProject.Click();

            AddNewProjectPage addNewProjectPage = new AddNewProjectPage();
            PageFactory.InitElements(driver, addNewProjectPage);
            addNewProjectPage.Customer.Click();
            SelectElement selectDropDown = new SelectElement(addNewProjectPage.Customer);
            selectDropDown.SelectByValue("2");

            addNewProjectPage.ProjectName.SendKeys("abc-4");
            addNewProjectPage.CustomerDescription.SendKeys("Adding fourth new project");
            addNewProjectPage.add_tasks_to_this_project.Click();
            addNewProjectPage.create_project_submit.Click();

        }

        [TestMethod]
        public void AddNewProjectSelectThirdRadiobutton()
        {

            LoginPageActions loginPageActions = new LoginPageActions(driver);
            loginPageActions.Login();
            navigation.ToProjectsAndCustomers();

            ProjectsAndCutomer projectsAndCutomer = new ProjectsAndCutomer();
            PageFactory.InitElements(driver, projectsAndCutomer);
            projectsAndCutomer.AddNewProject.Click();

            AddNewProjectPage addNewProjectPage = new AddNewProjectPage();
            PageFactory.InitElements(driver, addNewProjectPage);
            addNewProjectPage.Customer.Click();
            SelectElement selectDropDown = new SelectElement(addNewProjectPage.Customer);
            selectDropDown.SelectByValue("1");

            addNewProjectPage.ProjectName.SendKeys("abc-5");
            addNewProjectPage.CustomerDescription.SendKeys("Adding Fifth new project");
            addNewProjectPage.add_more_projects.Click();
            addNewProjectPage.create_project_submit.Click();

        }

        [TestMethod]
        public void AddNewProjectSelectThirdRadiobutton2()
        {

            LoginPageActions loginPageActions = new LoginPageActions(driver);
            loginPageActions.Login();
            navigation.ToProjectsAndCustomers();

            ProjectsAndCutomer projectsAndCutomer = new ProjectsAndCutomer();
            PageFactory.InitElements(driver, projectsAndCutomer);
            projectsAndCutomer.AddNewProject.Click();

            AddNewProjectPage addNewProjectPage = new AddNewProjectPage();
            PageFactory.InitElements(driver, addNewProjectPage);
            addNewProjectPage.Customer.Click();
            SelectElement selectDropDown = new SelectElement(addNewProjectPage.Customer);
            selectDropDown.SelectByValue("2");

            addNewProjectPage.ProjectName.SendKeys("abc-6");
            addNewProjectPage.CustomerDescription.SendKeys("Adding Sixth new project");
            addNewProjectPage.add_more_projects.Click();
            addNewProjectPage.create_project_submit.Click();

        }

        [TestMethod]
        public void AddNewProjectCancel1()
        {

            LoginPageActions loginPageActions = new LoginPageActions(driver);
            loginPageActions.Login();
            navigation.ToProjectsAndCustomers();

            ProjectsAndCutomer projectsAndCutomer = new ProjectsAndCutomer();
            PageFactory.InitElements(driver, projectsAndCutomer);
            projectsAndCutomer.AddNewProject.Click();

            AddNewProjectPage addNewProjectPage = new AddNewProjectPage();
            PageFactory.InitElements(driver, addNewProjectPage);
            addNewProjectPage.Customer.Click();
            SelectElement selectDropDown = new SelectElement(addNewProjectPage.Customer);
            selectDropDown.SelectByValue("1");
            
            addNewProjectPage.ProjectName.SendKeys("abc-1");
            addNewProjectPage.CustomerDescription.SendKeys("Adding first new project");
            addNewProjectPage.ShowList.Click();
            addNewProjectPage.Cancel.Click();            
            driver.SwitchTo().Alert().Accept();

        }

    }
}
