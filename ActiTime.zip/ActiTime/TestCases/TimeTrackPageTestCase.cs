﻿using ActiTime.PageActions;
using ActiTime.Pages;
using ActiTime.Pages.TimeTrack;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ActiTime.TestCases
{
    [TestClass]
    public class TimeTrackPageTestCase:TestBase
    {
        [TestMethod]
        public void TimeTrack()
        {
			LoginPageActions loginPageActions = new LoginPageActions(driver);
			loginPageActions.Login();

			navigation.ToTimeTrack();

			TimeTrackPage timeTrackPage = new TimeTrackPage();

            PageFactory.InitElements(driver, timeTrackPage);
            timeTrackPage.SelectUser.Click();
        }
    }
}
