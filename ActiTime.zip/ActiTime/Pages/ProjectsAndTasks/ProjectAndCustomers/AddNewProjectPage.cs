﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ActiTime.Pages.ProjectsAndTasks.ProjectAndCustomers
{
    class AddNewProjectPage
    {
        [FindsBy(How = How.Name, Using = "customerId")]
        public IWebElement Customer { get; set; }


		[FindsBy(How =How.Name, Using = "name")]
		public IWebElement ProjectName { get; set; }	

		[FindsBy(How = How.Name, Using = "description")]
        public IWebElement CustomerDescription { get; set; }

        [FindsBy(How = How.Id, Using = "active_projects_action")]
        public IWebElement ShowList { get; set; }

        [FindsBy(How = How.Id, Using = "add_tasks_action")]
        public IWebElement add_tasks_to_this_project { get; set; }

        [FindsBy(How = How.Id, Using = "add_more_projects")]
        public IWebElement add_more_projects { get; set; }

        [FindsBy(How = How.Id, Using = "add_project_action")]
        public IWebElement CreateNewProjec { get; set; }

        [FindsBy(How = How.Id, Using = "add_more_customers_action")]
        public IWebElement AddMoreCustomers { get; set; }

        [FindsBy(How = How.Name, Using = "createProjectSubmit")]
         public IWebElement create_project_submit { get; set; }

        
        //[FindsBy(How = How.XPath, Using = ".//*[@value='Create Project']")]
        //public IWebElement CreateProject { get; set; }

        [FindsBy(How = How.XPath, Using = ".//*[@value='    Cancel    ']")]
        public IWebElement Cancel { get; set; }


    }
}
