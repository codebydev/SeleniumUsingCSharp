﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ActiTime.Pages.ProjectsAndTasks.ProjectAndCustomers
{
    class AddNewCustomerPage
    {
        [FindsBy(How = How.Name, Using = "name")]
        public IWebElement CustomerName { get; set; }

        [FindsBy(How = How.Name, Using = "description")]
        public IWebElement CustomerDescription { get; set; }

        [FindsBy(How = How.Id, Using = "active_customers_action")]
        public IWebElement ShowList { get; set; }

        [FindsBy(How = How.Id, Using = "add_project_action")]
        public IWebElement CreateNewProjec { get; set; }

        [FindsBy(How = How.Id, Using = "add_more_customers_action")]
        public IWebElement AddMoreCustomers { get; set; }

        [FindsBy(How = How.XPath, Using = ".//*[@value='Create Customer']")]
        public IWebElement CreateUser { get; set; }

        [FindsBy(How = How.XPath, Using = ".//*[@value='      Cancel      ']")]
        public IWebElement Cancel { get; set; }

        [FindsBy(How = How.Id, Using = "add_project_action")]
        public IWebElement addProjectAction { get; set; }

        [FindsBy(How = How.Id, Using = "add_more_customers_action")]
        public IWebElement addMoreCustomersAction { get; set; }

        [FindsBy(How = How.ClassName, Using = "errormsg")]
        public IWebElement ErrorMessage { get; set; }

            }
}
