﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ActiTime.Pages.ProjectsAndTasks.OpenTask
{
    class AddNewTasksPage
    {
        [FindsBy(How = How.Name, Using = "customerId")]
        public IWebElement Customer { get; set; }

        [FindsBy(How = How.Name, Using = "customerName")]
        public IWebElement EnterCustomerName { get; set; }

        [FindsBy(How = How.Name, Using = "projectName")]
        public IWebElement CustomerProjectName { get; set; }

        [FindsBy(How = How.Name, Using = "projectId")]
        public IWebElement Project { get; set; }

        [FindsBy(How = How.Name, Using = "task[0].name ")]
        public IWebElement TaskName { get; set; }

        [FindsBy(How = How.Name, Using = "task[0].deadline")]
        public IWebElement Deadline { get; set; }

        [FindsBy(How = How.Name, Using = "task[0].billingType")]
        public IWebElement BillingType { get; set; }

    }
}
