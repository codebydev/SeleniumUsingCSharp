﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ActiTime.Pages.ProjectsAndTasks
{
    class OpenTasksPage
    {
   
       [FindsBy(How=How.Name,Using = "customerProject.shownCustomer")]
        public IWebElement CustomerDropDown { get; set; }

        [FindsBy(How = How.Name, Using = "customerProject.shownProject")]
        public IWebElement ProjectDropDown { get; set; }

        [FindsBy(How = How.Name, Using = "searchTasks")]
        public IWebElement ShowTasksButton { get; set; }

        [FindsBy(How = How.XPath, Using = ".//*[@value='Add New Tasks']")]
        public IWebElement AddNewTaskButton { get; set; }


    }


}
