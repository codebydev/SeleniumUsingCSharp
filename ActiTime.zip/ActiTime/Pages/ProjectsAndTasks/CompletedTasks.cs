﻿using OpenQA.Selenium;//Gated Checkins
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ActiTime.Pages.ProjectsAndTasks
{
    class CompletedTasks
    {
        [FindsBy(How = How.Id, Using = "shownCustomer")]
        public IWebElement Customer { get; set; }
        

        [FindsBy(How = How.Id, Using = "shownProject")]
        public IWebElement Customer1{ get; set; }

        [FindsBy(How = How.Name, Using = "completionDateFromMonth")]
        public IWebElement Month { get; set; }

        [FindsBy(How = How.Name, Using = "completionDateFromDay")]
        public IWebElement Day { get; set; }

        [FindsBy(How = How.Name, Using = "completionDateFromYear")]
        public IWebElement Year { get; set; }

        [FindsBy(How = How.Name, Using = "completionDateToMonth")]
        public IWebElement Month1 { get; set; }

        [FindsBy(How = How.Name, Using = "completionDateToDay")]
        public IWebElement Day1 { get; set; }

        [FindsBy(How = How.Name, Using = "completionDateToYear")]
        public IWebElement Year1 { get; set; }

        [FindsBy(How = How.Id, Using = "customerProjectStatus_active")]
        public IWebElement TaskToShow { get; set; }

        [FindsBy(How = How.XPath, Using = ".//input[@value='Show Tasks']")]
        public IWebElement ShowTasks { get; set; }

        [FindsBy(How = How.XPath, Using = ".//*[contains(text(),'Tasks from active & archived projects')] ")]
        public IWebElement Label { get; set; }

        [FindsBy(How = How.LinkText, Using = "clear dates")]
        public IWebElement CleaeDates { get; set;}
        [FindsBy(How = How.XPath, Using = ".//*[contains(text(),'The \"Completion Date\" filter was not applied.')]")]
        public IWebElement ErrorMessage { get; set; }

        [FindsBy(How = How.XPath, Using = ".//*[text()='There are no completed tasks found.']")]
        public IWebElement Message { get; set; }

        [FindsBy(How = How.XPath, Using = ".//*[contains(text(),'The \"Completion Date\" filter was not applied. The following fields are invalid:')]")]
        public IWebElement InvalidMessage{get; set;}


    }
}
