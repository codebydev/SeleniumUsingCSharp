﻿using OpenQA.Selenium;//Gated Checkins
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ActiTime.Pages.ProjectsAndTasks
{
    class ProjectsAndCutomer
    {
        [FindsBy(How=How.Name,Using="selectedCustomer")]
        public IWebElement SelectedCustomer { get; set; }

        [FindsBy(How = How.XPath, Using = ".//input[@value='Show Tasks']")]
        public IWebElement Show { get; set; }

        [FindsBy(How = How.Id, Using = "showProjects")]
        public IWebElement ShowProjects { get; set; }

        [FindsBy(How = How.XPath, Using = ".//input[@value='Add New Customer']")]
        public IWebElement AddNewCustomer { get; set; }

        [FindsBy(How = How.XPath, Using = ".//input[@value='Add New Project']")]
        public IWebElement AddNewProject { get; set; }

    }
}
