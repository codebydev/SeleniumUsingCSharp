﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ActiTime.Pages.Settings
{
    class BillingTypesPage
    {
        [FindsBy(How = How.LinkText, Using = "Billable")]
        public IWebElement Billing { get; set; }

        [FindsBy(How = How.LinkText, Using = "delete this billing type")]
        public IWebElement Delete { get; set; }

        [FindsBy(How = How.ClassName, Using = "notemsg")]
        public IWebElement NoteMessage { get; set; }

        [FindsBy(How = How.ClassName, Using = "successmsg")]
        public IWebElement SucceesMessage { get; set; }

        [FindsBy(How = How.ClassName, Using = "modified")]
        public IWebElement ModifiedMessage { get; set; }

        [FindsBy(How = How.XPath, Using = ".//input[@value='Save Changes']")]
        public IWebElement Savechanges { get; set; }

        [FindsBy(How = How.Id, Using = "FormModifiedDiv")]
        public IWebElement ModifiedMessage1 { get; set; }

        [FindsBy(How = How.Name, Using = "name")]
        public IWebElement Billable { get; set; }

        [FindsBy(How = How.XPath, Using = ".//input[@value='Add New Billing Type']")]
        public IWebElement AddNewBillingType1{ get; set; }

        [FindsBy(How = How.Name, Using = "name0")]
        public IWebElement Billing1 { get; set; }

        [FindsBy(How = How.XPath, Using = ".//input[@value='Create Billing Type(s)']")]
        public IWebElement Create { get; set; }
    }
}
