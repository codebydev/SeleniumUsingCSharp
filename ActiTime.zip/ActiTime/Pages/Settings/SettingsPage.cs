﻿using OpenQA.Selenium.Support.PageObjects;
using System;
using OpenQA.Selenium;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ActiTime.Pages
{
    class SettingsPage
    {
        [FindsBy(How = How.ClassName, Using = "menu_link")]
        public IWebElement Settings { get; set; }
    }
}
