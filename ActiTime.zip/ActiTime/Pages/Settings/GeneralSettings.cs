﻿using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using OpenQA.Selenium;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ActiTime.Pages.Settings
{
    class GeneralSettingsPage
    {
        // TOP LEVEL
        [FindsBy(How = How.Name, Using = "firstHierarchyLevelCode")]
        public IWebElement TopLevelName { get; set; }

        [FindsBy(How=How.Name,Using="firstHierarchyLevelSingularForm")]
        public IWebElement FirstSingularForm { get; set; }

        [FindsBy(How = How.Name, Using = "firstHierarchyLevelPluralForm")]
        public IWebElement FirstPluralForm { get; set; }

        //[FindsBy(How = How.XPath, Using = "..//option[@value='1']")]
        //public IWebElement TopLevelClientName { get; set; }

        //[FindsBy(How = How.XPath, Using = "..//option[@value='2']")]
        //public IWebElement TopLevelCustomerName { get; set; }

        //[FindsBy(How = How.XPath, Using = "..//option[@value='3']")]
        //public IWebElement TopLevelProductName { get; set; }

        //[FindsBy(How = How.XPath, Using = "..//option[@value='4']")]
        //public IWebElement TopLevelProductLineName { get; set; }

        //[FindsBy(How = How.XPath, Using = "..//option[@value='5']")]
        //public IWebElement TopLevelProjectName { get; set; }

        //MIDDLE LEVEL

        [FindsBy(How = How.XPath, Using = "..//option[@value='0']")]
        public IWebElement MiddleLevelCustomName { get; set; }

        [FindsBy(How = How.XPath, Using = "..//option[@value='6']")]
        public IWebElement MiddleLevelJobName { get; set; }

        [FindsBy(How = How.XPath, Using = "..//option[@value='7']")]
        public IWebElement MiddleLevelProjectName { get; set; }

        [FindsBy(How = How.XPath, Using = "..//option[@value='8']")]
        public IWebElement MiddleLevelProductName { get; set; }

        [FindsBy(How = How.XPath, Using = "..//option[@value='9']")]
        public IWebElement  MiddleLevelReleaseName { get; set; }

        [FindsBy(How = How.XPath, Using = "..//option[@value='10']")]
        public IWebElement MiddleLevelTaskName { get; set; }

        [FindsBy(How = How.Name, Using = "secondHierarchyLevelSingularForm")]
        public IWebElement SecondSingularForm { get; set; }

        [FindsBy(How = How.Name, Using = "secondHierarchyLevelPluralForm")]
        public IWebElement SecondPluralForm { get; set; }

        //Lowest Level

        [FindsBy(How = How.Name, Using = "thirdHierarchyLevelSingularForm")]
        public IWebElement ThirdSingularForm { get; set; }

        [FindsBy(How = How.Name, Using = "thirdHierarchyLevelPluralForm")]
        public IWebElement ThirdPluralForm { get; set; }

        [FindsBy(How = How.XPath, Using = ".//option[@value='0']")]
        public IWebElement LowestLevelCustomName { get; set; }

        [FindsBy(How = How.XPath, Using = ".//option[@value='11']")]
        public IWebElement LowestLevelTaskName { get; set; }

        [FindsBy(How = How.XPath, Using = ".//option[@value='12']")]
        public IWebElement LowestLevelSubTaskName { get; set; }

        //Date Format and Calendar




        //Calendar Layout

        [FindsBy(How = How.XPath, Using = "..//option[@value='US']")]
        public IWebElement CalendarWeeksStartsFromMonday { get; set; }

        [FindsBy(How = How.XPath, Using = "..//option[@value='EU']")]
        public IWebElement CalendarWeeksStartsFromSunday { get; set; }

        //Timesheet
        [FindsBy(How = How.XPath, Using = "..//input[@value='true']")]
        public IWebElement Limited { get; set; }

        [FindsBy(How = How.XPath, Using = "..//option[@value='60']")]
        public IWebElement HoursOne { get; set; }

        [FindsBy(How = How.XPath, Using = "..//option[@value='90']")]
        public IWebElement HoursOneThirty { get; set; }

        [FindsBy(How = How.XPath, Using = "..//option[@value='120']")]
        public IWebElement HoursTwo { get; set; }

        [FindsBy(How = How.XPath, Using = "..//option[@value='150']")]
        public IWebElement HoursTwoThirty { get; set; }

        [FindsBy(How = How.XPath, Using = "..//option[@value='180']")]
        public IWebElement HoursThree { get; set; }

        [FindsBy(How = How.XPath, Using = "..//option[@value='210']")]
        public IWebElement HoursThreeeThirty { get; set; }

        [FindsBy(How = How.XPath, Using = "..//option[@value='240']")]
        public IWebElement HoursFour { get; set; }

        [FindsBy(How = How.XPath, Using = "..//option[@value='270']")]
        public IWebElement HoursFourThirty { get; set; }

        [FindsBy(How = How.XPath, Using = "..//option[@value='300']")]
        public IWebElement HoursFive { get; set; }

        [FindsBy(How = How.XPath, Using = "..//option[@value='330']")]
        public IWebElement HoursFiveThirty { get; set; }

        [FindsBy(How = How.XPath, Using = "..//option[@value='360']")]
        public IWebElement HoursSix { get; set; }

        [FindsBy(How = How.XPath, Using = "..//option[@value='390']")]
        public IWebElement HoursSixThirty { get; set; }

        [FindsBy(How = How.XPath, Using = "..//option[@value='420']")]
        public IWebElement HoursSeven { get; set; }

        [FindsBy(How = How.XPath, Using = "..//option[@value='450']")]
        public IWebElement HoursSevenThirty { get; set; }

        [FindsBy(How = How.XPath, Using = "..//option[@value='480']")]
        public IWebElement HoursEight { get; set; }

        [FindsBy(How = How.XPath, Using = "..//option[@value='510']")]
        public IWebElement HoursEightThirty { get; set; }

        [FindsBy(How = How.XPath, Using = "..//option[@value='540']")]
        public IWebElement HoursNine { get; set; }

        [FindsBy(How = How.XPath, Using = "..//option[@value='570']")]
        public IWebElement HoursNineThirty { get; set; }

        [FindsBy(How = How.XPath, Using = "..//option[@value='600']")]
        public IWebElement HoursTen { get; set; }

        [FindsBy(How = How.XPath, Using = "..//option[@value='630']")]
        public IWebElement HoursTenThirty { get; set; }
        
        [FindsBy(How = How.XPath, Using = "..//option[@value='660']")]
        public IWebElement HoursEleven { get; set; }

        [FindsBy(How = How.XPath, Using = "..//option[@value='690']")]
        public IWebElement HoursElevenThirty { get; set; }

        [FindsBy(How = How.XPath, Using = "..//option[@value='720']")]
        public IWebElement HoursTwelve { get; set; }

        [FindsBy(How = How.XPath, Using = "..//option[@value='750']")]
        public IWebElement HoursTwelveThirty { get; set; }

        [FindsBy(How = How.XPath, Using = "..//option[@value='780']")]
        public IWebElement HoursThirteen { get; set; }

        [FindsBy(How = How.XPath, Using = "..//option[@value='810']")]
        public IWebElement HoursThirteenThirty { get; set; }

        [FindsBy(How = How.XPath, Using = "..//option[@value='840']")]
        public IWebElement HoursFourteen { get; set; }

        [FindsBy(How = How.XPath, Using = "..//option[@value='870']")]
        public IWebElement HoursFourteenThirty { get; set; }

        [FindsBy(How = How.XPath, Using = "..//option[@value='900']")]
        public IWebElement HoursFifteen { get; set; }

        [FindsBy(How = How.XPath, Using = "..//option[@value='930']")]
        public IWebElement HoursFifteenThirty { get; set; }

        [FindsBy(How = How.XPath, Using = "..//option[@value='960']")]
        public IWebElement HourSixteen { get; set; }

        [FindsBy(How = How.XPath, Using = "..//option[@value='990']")]
        public IWebElement HoursSixteenThirty { get; set; }

        [FindsBy(How = How.XPath, Using = "..//option[@value='1020']")]
        public IWebElement HoursSeventeen { get; set; }

        [FindsBy(How = How.XPath, Using = "..//option[@value='1050']")]
        public IWebElement HoursSeventeenThirty { get; set; }

        [FindsBy(How = How.XPath, Using = "..//option[@value='1080']")]
        public IWebElement HoursEighteen { get; set; }

        [FindsBy(How = How.XPath, Using = "..//option[@value='1110']")]
        public IWebElement HoursEighteenThirty { get; set; }
        
        [FindsBy(How = How.XPath, Using = "..//option[@value='1140']")]
        public IWebElement HoursNineteen { get; set; }

        [FindsBy(How = How.XPath, Using = "..//option[@value='1170']")]
        public IWebElement HoursNineteenThirty { get; set; }

        [FindsBy(How = How.XPath, Using = "..//option[@value='1200']")]
        public IWebElement HoursTwenty { get; set; }

        [FindsBy(How = How.XPath, Using = "..//option[@value='1230']")]
        public IWebElement HoursTwentyThirty { get; set; }
        //
        [FindsBy(How = How.XPath, Using = "..//option[@value='1260']")]
        public IWebElement HoursTwentyOne { get; set; }

        [FindsBy(How = How.XPath, Using = "..//option[@value='1290']")]
        public IWebElement HoursTwentyOneThirty { get; set; }

        [FindsBy(How = How.XPath, Using = "..//option[@value='1320']")]
        public IWebElement HoursTwentyTwo { get; set; }

        [FindsBy(How = How.XPath, Using = "..//option[@value='1350']")]
        public IWebElement HoursTwentyTwoThirty { get; set; }

        [FindsBy(How = How.XPath, Using = "..//option[@value='1380']")]
        public IWebElement HoursTwentyThree { get; set; }

        [FindsBy(How = How.XPath, Using = "..//option[@value='1410']")]
        public IWebElement HoursTwentyThreeThirty { get; set; }

        [FindsBy(How = How.XPath, Using = "..//option[@value='1440']")]
        public IWebElement HoursTwentyFour { get; set; }

        [FindsBy(How = How.XPath, Using = "..//input[@value='false']")]
        public IWebElement UnLimited { get; set; }

        //OVERTIME/UNDERTIME
        [FindsBy(How=How.XPath,Using="..//input[@value='both']")]
        public IWebElement CollectBothOvertimeAndUndertime { get; set; }

        [FindsBy(How = How.XPath, Using = "..//input[@value='overtime']")]
        public IWebElement CollectOvertimeOnly { get; set; }

        //CSV FORMAT
        [FindsBy(How = How.Id, Using = "csvMultilanguage_multilanguage")]
        public IWebElement  SupportInternationalCharactersCSVReports { get; set; }

        [FindsBy(How = How.Id, Using = "csvMultilanguage_custom")]
        public IWebElement SupportOnlyWindowsCharactersCSVReports { get; set; }
    }
}
