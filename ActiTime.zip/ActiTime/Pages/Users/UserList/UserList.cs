﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ActiTime.Pages.Users.UserList
{
    class UserList
    {
        [FindsBy(How = How.XPath, Using = ".//*[@value='Add New User']")]
        public IWebElement AddNewUser { get; set; }
    }
}
