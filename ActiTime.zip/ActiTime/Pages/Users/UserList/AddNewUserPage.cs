﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ActiTime.Pages.Users.UserList
{
    class AddNewUserPage
    {
        [FindsBy(How = How.Name, Using = "username")]
        public IWebElement UserName { get; set; }

        [FindsBy(How = How.Name, Using = "passwordText")]
        public IWebElement Password { get; set; }

        [FindsBy(How = How.Name, Using = "passwordTextRetype")]
        public IWebElement RetypePassword { get; set; }

        [FindsBy(How = How.Name, Using = "active")]
        public IWebElement Access { get; set; }

        [FindsBy(How = How.Name, Using = "firstName")]
        public IWebElement FirstName { get; set; }

        [FindsBy(How = How.Name, Using = "lastName")]
        public IWebElement LastName { get; set; }

        [FindsBy(How = How.Name, Using = "middleName")]
        public IWebElement MiddleIntial { get; set; }

        [FindsBy(How = How.Name, Using = "email")]
        public IWebElement EMailAddress { get; set; }

        [FindsBy(How = How.Name, Using = "phone")]
        public IWebElement Phone { get; set; }

        [FindsBy(How = How.Name, Using = "fax")]
        public IWebElement Fax { get; set; }

        [FindsBy(How = How.Name, Using = "mobile")]
        public IWebElement Mobile { get; set; }

        [FindsBy(How = How.Name, Using = "otherContact")]
        public IWebElement OtherContact { get; set; }

        [FindsBy(How = How.Name, Using = "overtimeTracking")]
        public IWebElement EnableovertimeTracking { get; set; }

        [FindsBy(How = How.Name, Using = "workdayDuration")]
        public IWebElement WorkdayDuration { get; set; }

        [FindsBy(How = How.Id, Using = "overtimeTrackingLevel_Hidden")]
        public IWebElement OvertimeTrackingLevelHiddenle { get; set; }

        [FindsBy(How = How.Id, Using = "overtimeTrackingLevel_ReadOnly")]
        public IWebElement OvertimeTrackingLevelReadOnly { get; set; }

        [FindsBy(How = How.Id, Using = "overtimeTrackingLevel_Trusted")]
        public IWebElement OvertimeTrackingLevelTrusted { get; set; }

        [FindsBy(How = How.Id, Using = "overtimeTracking_Disable")]
        public IWebElement DisableOvertimeTracking { get; set; }

        [FindsBy(How = How.Id, Using = "right9")]
        public IWebElement EnterTimeTrack { get; set; }

        [FindsBy(How = How.Id, Using = "right12")]
        public IWebElement EnterModifyTimeTrackOfOtheUsers { get; set; }

        [FindsBy(How = How.Id, Using = "right2")]
        public IWebElement ManageCustomersProjectsTasks { get; set; }



    }
}
