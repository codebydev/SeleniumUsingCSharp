﻿using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ActiTime.Pages
{
    class MyAccount
    {
        [FindsBy(How=How.Name,Using="passwordCur")]
        public IWebElement CustomerPassword { get; set; }

        [FindsBy(How=How.Name,Using="passwordNew")]
        public IWebElement NewPassword { get; set; }

        [FindsBy(How = How.Name, Using = "passwordRetype")]
        public IWebElement RetypePassword { get; set; }

        [FindsBy(How = How.Name, Using = "firstName")]
        public IWebElement FirstName { get; set; }

        [FindsBy(How = How.Name, Using = "lastName")]
        public IWebElement LastName { get; set; }

        [FindsBy(How = How.Name, Using = "middleName")]
        public IWebElement MiddleInitial { get; set; }

        [FindsBy(How = How.Name, Using = "email")]
        public IWebElement EmailAddress { get; set; }

        [FindsBy(How = How.Name, Using = "phone")]
        public IWebElement Phone { get; set; }

        [FindsBy(How = How.Name, Using = "fax")]
        public IWebElement Fax { get; set; }

        [FindsBy(How = How.Name, Using = "mobile")]
        public IWebElement Mobile { get; set; }

        [FindsBy(How = How.Name, Using = "otherContact")]
        public IWebElement OtherContact { get; set; }

        [FindsBy(How = How.XPath, Using = ".//*[@type='submit']")]
        public IWebElement SaveChanges { get; set; }

    }
}
