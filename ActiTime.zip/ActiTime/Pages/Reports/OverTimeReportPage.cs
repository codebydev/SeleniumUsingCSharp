﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ActiTime.Pages.Reports
{   
    class OverTimeReportPage
    {
        [FindsBy(How=How.Id, Using = "users_all")]
        public IWebElement Users_all { get; set; }

		[FindsBy(How =How.Id, Using = "users_selected")]
		public IWebElement users_selected { get; set; }

		[FindsBy(How=How.Name, Using = "firstLevel")]
        public IWebElement FirstLevel { get; set; } 

        [FindsBy(How =How.Name, Using = "secondLevel")]
        public IWebElement SecondLevel { get; set; }

        [FindsBy(How =How.Name, Using = "fromMonth")]
        public IWebElement FromMonth { get; set; }

		[FindsBy(How =How.Name, Using = "fromDay")]
        public IWebElement FromDay { get; set; }

		[FindsBy(How = How.Name, Using = "fromYear")]
		public IWebElement FromYear { get; set; }

		[FindsBy(How =How.XPath, Using = ".//*[@value='Set Current Month']")]
        public IWebElement Set_Current_Month { get; set; }

        [FindsBy(How =How.Name, Using = "toMonth")]
        public IWebElement ToMonth { get; set; }

        [FindsBy(How =How.Name, Using = "toDay")]
        public IWebElement ToDay { get; set; }

        [FindsBy(How =How.Name, Using = "toYear")]
        public IWebElement ToYear { get; set; }

        [FindsBy(How =How.XPath, Using = ".//*[@Value='Set Current Week']")]
        public IWebElement Set_Current_Week { get; set; }

        [FindsBy(How =How.XPath, Using = ".//*[@Value='< Month']")]
        public IWebElement Month { get; set; }

        [FindsBy(How =How.XPath, Using = ".//*[@Value='< Week']")]
        public IWebElement Week { get; set; }

        [FindsBy(How =How.XPath, Using = ".//*[@Value='Week >']")]
        public IWebElement Week1 { get; set; }
        
        [FindsBy(How =How.XPath, Using = ".//*[@Value='Month >']")]
        public IWebElement Month1 { get; set; }

        [FindsBy(How =How.XPath, Using = ".//*[@Value='Generate HTML Report']")]
        public IWebElement Generate_HTML_Report { get; set; }

        [FindsBy(How =How.Name, Using = "genCSV")]
        public IWebElement genCSV { get; set; }

    }   
}
