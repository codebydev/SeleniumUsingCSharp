﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ActiTime.Pages.Reports.OverTimeReport
{
    class GenerateHTMLReportPage
    {
		[FindsBy(How = How.LinkText, Using = "<< Change report parameters")]
		public IWebElement Change_report_Parameter { get; set; }

		[FindsBy(How = How.LinkText, Using = "Export to CSV format")]
		public IWebElement Export_to_CSV_format { get; set; }
	}
}
