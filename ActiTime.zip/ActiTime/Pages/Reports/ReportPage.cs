﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ActiTime.Pages.Reports
{
    class ReportPage
    {
        [FindsBy(How=How.ClassName,Using="menu_link")]
        public IWebElement Reports { get; set; }
    }
}
