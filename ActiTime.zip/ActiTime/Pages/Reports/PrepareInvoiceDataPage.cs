﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ActiTime.Pages.Reports
{
    class PrepareInvoiceDataPage
    {
        [FindsBy(How = How.Id, Using = "customerProjectStatus_active")]
        public IWebElement InvoiceForActiveCustomers { get; set; }

        [FindsBy(How = How.Id, Using = "customerProjectStatus_all")]
        public IWebElement InvoiceForActivArchived { get; set; }

        [FindsBy(How = How.Name, Using = "customerId")]
        public IWebElement Customer { get; set; }

        [FindsBy(How = How.Id, Using = "rangeType_time_reported")]
        public IWebElement BillByTimeReported { get; set; }

        [FindsBy(How = How.Id, Using = "rangeType_time_spent")]
        public IWebElement BillByTimeSpent { get; set; }
        

        [FindsBy(How = How.XPath, Using = ".//*[@value='Set Current Month']")]
        public IWebElement SetCurrentMonth { get; set; }

        [FindsBy(How = How.XPath, Using = ".//*[@value='Set Current Week']")]
        public IWebElement SetCurrentWeek { get; set; }

        [FindsBy(How = How.XPath, Using = ".//*[@value='< Month']")]
        public IWebElement GreaterMonth { get; set; }

        [FindsBy(How = How.XPath, Using = ".//*[@value='< Week']")]
        public IWebElement LessWeek { get; set; }
        
        [FindsBy(How = How.XPath, Using = ".//*[@value='Week >']")]
        public IWebElement WeekGreater { get; set; }

        [FindsBy(How = How.XPath, Using = ".//*[@value='Month >']")]
        public IWebElement MonthGreater { get; set; }

        [FindsBy(How = How.Name, Using = "projects")]
        public IWebElement CooseCustomerProjects { get; set; }

        [FindsBy(How = How.Id, Using = "invoiceType_groupByBillingTypes")]
        public IWebElement ShowTasksGrouped { get; set; }

        [FindsBy(How = How.Id, Using = "invoiceType_plainListOfTasks")]
        public IWebElement ShowPlainList { get; set; }

        [FindsBy(How = How.Id, Using = "invoiceType_plainListOfProjects")]
        public IWebElement HideTasksShowProjects { get; set; }

        [FindsBy(How = How.XPath, Using = ".//*[@value='Preview in HTML/Export for Quickbooks']")]
        public IWebElement PreviewInHtmlExport  { get; set; }

    }

}
