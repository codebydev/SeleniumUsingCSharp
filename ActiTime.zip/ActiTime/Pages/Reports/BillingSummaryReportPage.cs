﻿//using OpnQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;

namespace ActiTime.Pages.Reports
{
    class BillingSummaryReportPage
    {
               
        [FindsBy(How = How.Id, Using = "type_time_reported")]
        public IWebElement Timereportedforadaterange { get; set; }

        [FindsBy(How = How.Id, Using = "type_time_spent")]
        public IWebElement Timespentontaskscompletedwithinadaterange { get; set; }

        [FindsBy(How = How.Name, Using = "fromMonth")]
        public IWebElement Month { get; set;}

        [FindsBy(How = How.Name, Using = "fromDay")]
        public IWebElement Day{ get; set; }


        [FindsBy(How = How.Name, Using = "fromYear")]
        public IWebElement Year { get; set; }
        

        [FindsBy(How = How.ClassName, Using = "daterangebutton")]
        public IWebElement SetCurrnetMonth { get; set; }

        
        [FindsBy(How = How.Name,Using = "toMonth")]
        public IWebElement ToMonth { get; set; }

          
        [FindsBy(How = How.Name, Using = "toDay")]
        public IWebElement ToDay { get; set; }


        [FindsBy(How = How.Name, Using = "toYear")]
        public IWebElement ToYear { get; set; }


        [FindsBy(How = How.XPath, Using = ".//*[@value='Set Current Week']")]
        public IWebElement SetCurrnetWeek { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@value='< Month']")]
        public IWebElement Monthb { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@value='< Week']")]
        public IWebElement Weekb { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@value='Week >']")]
        public IWebElement Weekb1 { get; set; }


        [FindsBy(How = How.XPath, Using = "//input[@value='Month >']")]
        public IWebElement Monthb1 { get; set; }


        [FindsBy(How = How.Id, Using = "tasks_billable")]
        public IWebElement Billabletasks { get; set; }

        
        [FindsBy(How = How.Id, Using = "tasks_nonbillable")]
        public IWebElement NonBillabletasks { get; set; }

        [FindsBy(How = How.Id, Using = "tasks_all")]
        public IWebElement BothBillableandNonBillabletasks { get; set; }

        [FindsBy(How = How.Id, Using = "customerProjectStatus_all")]
        public IWebElement ReportOnActiveAndArchived { get; set; }


        [FindsBy(How = How.Name, Using = "customerId")]
        public IWebElement CustomerId { get; set; }

        [FindsBy(How = How.XPath, Using = ".//*[@value='Generate HTML Report']")]
        public IWebElement GenerateHTML{ get; set; }

    }
}
    