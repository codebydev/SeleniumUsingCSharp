﻿using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ActiTime.Pages.Reports
{
    class StaffOutputReportPagee
    {
        [FindsBy(How=How.Id,Using="users_all")]
        public IWebElement  AllStaff { get; set; }

        [FindsBy(How=How.Id,Using="users_selected")]
        public IWebElement SelectedStaff { get; set; }

        [FindsBy(How = How.Name, Using = "users")]
        public IWebElement SystemAdministrator { get; set; }

        [FindsBy(How = How.Name, Using = "showDisabledUsers")]
        public IWebElement ShowUsersWithDisabledAccess { get; set; }

        [FindsBy(How = How.Name, Using = "firstGrouping")]
        public IWebElement ResultByFirst { get; set; }

        [FindsBy(How = How.Name, Using = "secondGrouping")]
        public IWebElement groupBySecond { get; set; }

        [FindsBy(How = How.Name, Using = "detailsLevel")]
        public IWebElement Detail { get; set; }

        [FindsBy(How = How.Name, Using = "fromMonth")]
        public IWebElement FromMonth { get; set; }

        [FindsBy(How = How.Name, Using = "fromDay")]
        public IWebElement FromDay { get; set; }

        [FindsBy(How = How.Name, Using = "fromYear")]
        public IWebElement FromYear { get; set; }

        [FindsBy(How = How.XPath, Using = ".//*[@value='Set Current Month']")]
        public IWebElement SetCurrentMonth { get; set; }

        [FindsBy(How = How.Name, Using = "toMonth")]
        public IWebElement ToMonth { get; set; }

        [FindsBy(How = How.Name, Using = "toDay")]
        public IWebElement ToDay { get; set; }

        [FindsBy(How = How.Name, Using = "toYear")]
        public IWebElement ToYear { get; set; }

        [FindsBy(How = How.XPath, Using = ".//*[@value='Set Current Week']")]
        public IWebElement SetCurrentWeek { get; set; }

        [FindsBy(How = How.XPath, Using = ".//*[@value='< Month']")]
        public IWebElement MonthLessThan { get; set; }

        [FindsBy(How = How.XPath, Using = ".//*[@value='< Week']")]
        public IWebElement WeekLessThan { get; set; }

        // [FindsBy(How = How.XPath, Using = ".//*[@value='Set Current Week']")]
        //public IWebElement SetCurrentWeek { get; set; }

        [FindsBy(How = How.XPath, Using = ".//*[@value='Week >']")]
        public IWebElement MonthGreaterThan { get; set; }

        [FindsBy(How = How.XPath, Using = ".//*[@value='Month >']")]
        public IWebElement WeekGreaterThan { get; set; }

        [FindsBy(How = How.Id, Using = "customerProjectStatus_active")]
        public IWebElement ReportOnActiveCustomersAndProjectsOnly { get; set; }

        [FindsBy(How = How.Id, Using = "customerProjectStatus_all")]
        public IWebElement ReportOnActiveAndArchivedCustomersOrprojects { get; set; }

        [FindsBy(How = How.Name, Using = "customerId")]
        public IWebElement Customer { get; set; }

        [FindsBy(How = How.Name, Using = "projectId")]
        public IWebElement Project{ get; set; }

        [FindsBy(How = How.Name, Using = "genHTML")]
        public IWebElement GenerateHTMLReport { get; set; }

        [FindsBy(How = How.Name, Using = "genCSV")]
        public IWebElement GenerateCSVReport{ get; set; }
    }
}
