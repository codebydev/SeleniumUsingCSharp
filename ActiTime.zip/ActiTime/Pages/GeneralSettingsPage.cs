﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ActiTime.Pages
{
    class GeneralSettingsPage
    {
        [FindsBy(How=How.Name,Using="firstHierarchyLevelCode")]
        public IWebElement TopLevel{ get; set; }

        [FindsBy(How=How.Name,Using="secondHierarchyLevelCode")]
        public IWebElement MiddleLevel { get; set; }

        [FindsBy(How=How.Name,Using="thirdHierarchyLevelCode")]
        public IWebElement LowestLevel { get; set; }

        [FindsBy(How=How.Name,Using="dateFormat")]
        public IWebElement DateFormat { get; set; }

        [FindsBy(How = How.Name, Using = "calendarLayout")]
        public IWebElement CalendarLayout { get; set; }


        [FindsBy(How = How.Id, Using = "hoursPerDayLimited_LimitTo")]
        public IWebElement Limitto { get; set; }

        [FindsBy(How = How.Id, Using = "hoursPerDayLimited_Unlimited")]
        public IWebElement Unlimited { get; set; }

        [FindsBy(How = How.Name, Using = "maximumMinutesPerDay")]
        public IWebElement MaximumHoursPerDay { get; set; }

        [FindsBy(How = How.Id, Using = "overtime_undertime")]
        public IWebElement Collectbothovertimeandundertime { get; set; }

        [FindsBy(How = How.Id, Using = "overtime_only")]
        public IWebElement Collectovertimeonly { get; set; }

        [FindsBy(How = How.Id, Using = "csvMultilanguage_multilanguage")]
        public IWebElement SupportinternationalcharactersCSVreportsusepredefinedfieldseparator { get; set; }

        [FindsBy(How = How.Id, Using = "csvMultilanguage_custom")]
        public IWebElement SupportonlywindowscharactersinCSVreportsuseconfigurablefieldseparator { get; set; }

        [FindsBy(How = How.Name, Using = "separator")]
        public IWebElement FieldseparatortobeusedwhengeneratingreportsinCSVformat { get; set; }

        [FindsBy(How=How.Name,Using="workdayDuration")]
        public IWebElement DefaultWorkdayDuration { get; set; }

        [FindsBy(How=How.XPath,Using=".//*[@value='Save Settings']")]
        public IWebElement SaveSettings { get; set; }
    }
}
