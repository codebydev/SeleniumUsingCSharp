﻿using ActiTime.Pages;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using RelevantCodes.ExtentReports;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ActiTime.PageActions
{
    public class LoginPageActions: TestBase
    {
        public LoginPageActions(IWebDriver d)
        {
            driver = d;
        }
        public void Login()
        {
            LoginPage loginpage = new LoginPage();
             
            PageFactory.InitElements(driver, loginpage);
           // test.Log(LogStatus.Info, "Launced Acttime Login Page sucessufully");
            loginpage.UserName.SendKeys("admin");
           // test.Log(LogStatus.Info, "Enterd the UserName as admin in username text field");
            loginpage.PassWord.SendKeys("manager");
           // test.Log(LogStatus.Info, "Enterd the Password as manager in password text field");
            loginpage.LoginNow.Click();
           // test.Log(LogStatus.Info, "Click Event Done on LoginNow button");
           // test.Log(LogStatus.Pass, "Executed all the test cases");

        }

    }
}
