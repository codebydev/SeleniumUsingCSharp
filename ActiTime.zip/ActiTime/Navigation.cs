﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ActiTime
{
    public class Navigation : TestBase //Navigation is Inherit from testbase
    {
        IWebElement element;

        public Navigation(IWebDriver d)
        {
            driver = d;
        }

        private void ToProjectsAndTasks()
        {
            element = driver.FindElement(By.XPath(".//*[text()='Projects & Tasks']"));
            if (element.TagName == "a")
            {
                element.Click();
            }
        }
        public void ToOpenTasks()
        {

            ToProjectsAndTasks();
            element = driver.FindElement(By.XPath(".//*[text()='Open Tasks']"));
            if (element.TagName == "a")
            {
                element.Click();
            }
        }

        public void ToCompletedTasks()
        {
            ToProjectsAndTasks();

            element = driver.FindElement(By.XPath(".//*[text()='Completed Tasks']"));
            if (element.TagName == "a")
            {
                element.Click();
            }
        }

        public void ToProjectsAndCustomers()
        {
            ToProjectsAndTasks();

            element = driver.FindElement(By.XPath(".//*[text()='Projects & Customers']"));
            if (element.TagName == "a")
            {
                element.Click();
            }
        }

        public void ToArchives()
        {
            ToProjectsAndTasks();

            element = driver.FindElement(By.XPath(".//*[text()='Archives']"));
            if (element.TagName == "a")
            {
                element.Click();
            }
        }

        public void ToTimeTrack()
        {
            element = driver.FindElement(By.XPath(".//*[text()='Time-Track']"));
            if (element.TagName == "a")
            {
                element.Click();
            }
        }

        private void ToReports()
        {
            element = driver.FindElement(By.XPath(".//*[text()='Reports']"));
            if (element.TagName == "a")
            {
                element.Click();
            }
        }

        public void ToStaffOutputReport()
        {
            ToReports();

            element = driver.FindElement(By.XPath(".//*[text()='Staff Output Report']"));
            if (element.TagName == "a")
            {
                element.Click();
            }
        }

        public void ToBillingSummaryReport()
        {
            ToReports();

            element = driver.FindElement(By.XPath(".//*[text()='Billing Summary Report']"));
            if (element.TagName == "a")
            {
                element.Click();
            }
        }
        public void ToOvertimeReport()
        {
            ToReports();

            element = driver.FindElement(By.XPath(".//*[text()='Overtime Report']"));
            if (element.TagName == "a")
            {
                element.Click();
            }
        }

        public void ToPrepareInvoiceData()
        {
            ToReports();

            element = driver.FindElement(By.XPath(".//*[text()='Prepare Invoice Data']"));
            if (element.TagName == "a")
            {
                element.Click();
            }
        }

        public void ToUsers()
        {
            element = driver.FindElement(By.XPath(".//*[text()='Users']"));
            if (element.TagName == "a")
            {
                element.Click();
            }
        }

        public void ToWorkSchedule()
        {
            element = driver.FindElement(By.XPath(".//*[text()='Work Schedule']"));
            if (element.TagName == "a")
            {
                element.Click();
            }
        }

        private void ToSettings()
        {
            element = driver.FindElement(By.XPath(".//*[text()='Settings']"));
            if (element.TagName == "a")
            {
                element.Click();
            }
        }
        public void ToBillingTypes()
        {
            ToSettings();

            element = driver.FindElement(By.XPath(".//*[text()='Billing Types']"));
            if (element.TagName == "a")
            {
                element.Click();
            }
        }

        public void ToGeneralSettings()
        {
            ToSettings();

            element = driver.FindElement(By.XPath(".//*[text()='General Settings']"));
            if (element.TagName == "a")
            {
                element.Click();
            }
        }

        public void ToMyAccount()
        {
            element = driver.FindElement(By.XPath(".//*[text()='My Account']"));
            if (element.TagName == "a")
            {
                element.Click();
            }
        }
    }
}
