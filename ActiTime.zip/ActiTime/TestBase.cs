﻿using ActiTime.Utilities;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Support.Events;
using RelevantCodes.ExtentReports;
using System;
using System.Configuration;
using System.Drawing.Imaging;

namespace ActiTime
{
    [TestClass]
    public class TestBase

    {
        protected IWebDriver driver;
        private TestContext testcontext;
        protected Navigation navigation;
        protected ExtentTest test; // variable " test " 

        private static ExtentReports extentReport;// creating object from the library extent reports

        public TestContext TestContext
        {
            set {testcontext=value; }
            get {return testcontext; }
        }

        [AssemblyInitialize]
        public static void AssemblyInitialize(TestContext testcontext)
        {
            extentReport = new ExtentReports("Report.html");

			extentReport.LoadConfig("ExtentReportsSettings.xml");

        }

        [TestInitialize]
        public void TestInitialize()
        {
            test = extentReport.StartTest(TestContext.TestName); // created the object for the extent report for extentreport (library)
            string browser = ConfigurationManager.AppSettings["Browser"].ToUpper();
    
            switch(browser)
            {
                case "FIREFOX":
                    driver = new FirefoxDriver();
                    break;

                case "IE":
                    driver = new InternetExplorerDriver();
                    break;
                case "CHROME":
                    driver = new ChromeDriver();                   
                    break;
                default:
                    break;
            }

            EventFiringWebDriver eventDriver = new EventFiringWebDriver(driver); // Creating event firing web driver which helps to take screen shots.
            eventDriver.ExceptionThrown += eventDriver_ExceptionThrown; // It is a deligate which points to eventDriver_ExceptionThrown
            
            // assign the modified event driver to driver
            driver = eventDriver;
            
            // read the URL from the app.config
            driver.Url = ConfigurationManager.AppSettings["Url"];
            navigation = new Navigation(driver);

            // Initial Browser Settings
            driver.Manage().Window.Maximize();
            driver.Manage().Timeouts().ImplicitlyWait(TimeSpan.FromSeconds(60)); // Settings driver time to come into existance
            driver.Manage().Timeouts().SetPageLoadTimeout(TimeSpan.FromSeconds(120)); //page loading time
         }

       private void eventDriver_ExceptionThrown(object sender, WebDriverExceptionEventArgs e)
        {

            test.Log(LogStatus.Fail, "Failed test cases");

            ((ITakesScreenshot)driver).GetScreenshot().SaveAsFile(TestContext.TestName + ".png", ImageFormat.Png);
        }          


        [TestCleanup]
        public void TestCleanUp()
        {
            driver.Quit();
        }


        [AssemblyCleanup]
        public static void AssemblyCleanUp()
        {
            //extentReport.Close();
            extentReport.Flush(); // move to hard disk
        
            Mailer.SendMail("youremailid@gmail.com;anotheremailid@gmail.com", "Regression Testing - Cycle 1", "<i><b>Regression Testing cycle 7</b></i>");        
        }


        public EventFiringWebDriver EventDriver { get; set; }
    }
}
